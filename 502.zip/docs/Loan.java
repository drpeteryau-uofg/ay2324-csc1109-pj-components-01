import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import javax.swing.*;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.awt.Dimension;

/**
 * The {@code Loan} class represents a loan object with detailed information about a loan.
 * It includes properties such as loan type, loan ID, loan amount, interest rate, loan term,
 * monthly payment amount, total payment amount, loan status, and dates for when the loan
 * was opened and when it's expected to close. This class is designed to manage the details
 * of a loan within a banking or financial application context.
 * 
 * Each {@code Loan} object is associated with static instances of an {@code Account},
 * a {@code Bank}, and a {@code Customer}, indicating the integration of the loan
 * with broader banking system components. The {@code APPLICATION_FEE} is a constant
 * representing the fee charged to apply for the loan.
 *
 * 
 * 
 * Attributes:
 * - {@code loanType}: The type of loan (e.g., "Home Loan", "Car Loan").
 * - {@code loanID}: A unique identifier for the loan.
 * - {@code loanAmount}: The total amount of the loan.
 * - {@code interestRate}: The interest rate of the loan in percentage.
 * - {@code loanTerm}: The term of the loan in months.
 * - {@code monthlyPayment}: The calculated monthly payment amount.
 * - {@code totalPayment}: The total amount to be paid over the life of the loan.
 * - {@code loanStatus}: The current status of the loan (e.g., "Open", "Closed").
 * - {@code loanDate}: The date the loan was initiated.
 * - {@code loanCloseDate}: The expected date for the loan to be fully repaid.
 * - {@code APPLICATION_FEE}: A static final value representing the application fee required to apply for the loan.
 */
public class Loan {
    private String loanType;
    private String loanID;
    private double loanAmount;
    private double interestRate;
    private int loanTerm;
    private double monthlyPayment;
    private double totalPayment;
    private String loanStatus;
    private Date loanDate; //get the loan date when they apply for the loan
    private Date loanCloseDate;
    private static Account account = new Account();
    private static final double APPLICATION_FEE = 5.00; // Example application fee amount
    //private Customer customer; // Customer who applied for the loan
    //private Bank bank;
    private static Bank bank = new Bank(); // Create a new Bank object
    private static Customer customer = new Customer(); // Create a new Customer object
    //Loan loan = new Loan(bank); // Create a new Loan object
    //customer.applyForLoan(loan); // Apply for a loan
    //loan.setBank(bank); // Set the bank for the loan

/**
 * Constructs a new Loan object associated with a specified bank.
 * This constructor initializes a Loan object and links it to a given Bank instance.
 * It ensures that the loan has a valid bank association upon creation. If the provided
 * bank parameter is null, the constructor throws an IllegalArgumentException to prevent
 * the creation of a Loan object without a valid bank association.
 *
 * @param bank The Bank instance to which this Loan is associated. Must not be null.
 * @throws IllegalArgumentException if the bank parameter is null, indicating that a valid bank
 *         association is required for the Loan object to be created.
 */
    public Loan (Bank bank) {
        if (bank == null) {
            throw new IllegalArgumentException("Bank cannot be null");
        }
        this.bank = bank;
    }

/**
 * Constructs a new Loan object with the specified loan amount.
 *
 * @param loanAmount the amount of the loan
 */
    public Loan(double loanAmount) {
        this.loanAmount = loanAmount;  
    }

/**
 * Constructs a new Loan object with default values.
 * This constructor initializes a Loan object with empty strings for loanType and loanID,
 * zeros for numeric values such as loanAmount, interestRate, loanTerm, monthlyPayment,
 * and totalPayment. The loanStatus is also initialized to an empty string. The dates
 * for loanDate and loanCloseDate are set to the current date and time at the moment
 * of object creation.
 * 
 * Use this constructor to create a Loan object before setting its properties explicitly
 * via setter methods or other mechanisms. This is useful when the details of the loan
 * are not known at the time of object creation or when they need to be obtained
 * dynamically.
 */
    public Loan() {
        this.loanType = "";
        this.loanID = "";
        this.loanAmount = 0;
        this.interestRate = 0;
        this.loanTerm = 0;
        this.monthlyPayment = 0;
        this.totalPayment = 0;
        this.loanStatus = "";
        this.loanDate = new Date();
        this.loanCloseDate = new Date();
    }

/**
 * Returns the type of the loan.
 *
 * @return the type of the loan
 */
    public String getLoanType() {
        return this.loanType;
    }

/**
 * Sets the type of the loan.
 *
 * @param loanType the new type of the loan
 */
    public void setLoanType(String loanType) {
        this.loanType = loanType;
    }

/**
 * Returns the amount of the loan.
 *
 * @return the amount of the loan
 */
    public double getLoanAmount() {
        return loanAmount;
    }

/**
 * Sets the amount of the loan.
 *
 * @param loanAmount the new amount of the loan
 */
    public void setLoanAmount(double loanAmount) {
        this.loanAmount = loanAmount;
    }

/**
 * Returns the interest rate of the loan.
 *
 * @return the interest rate of the loan
 */
    public double getInterestRate() {
        return interestRate;
    }

/**
 * Sets the interest rate of the loan.
 *
 * @param interestRate the new interest rate of the loan
 */
    public void setInterestRate(double interestRate) {
        this.interestRate = interestRate;
    }

/**
 * Returns the term of the loan.
 *
 * @return the term of the loan
 */
    public int getLoanTerm() {
        return loanTerm;
    }

/**
 * Sets the term of the loan.
 *
 * @param loanTerm the new term of the loan
 */
    public void setLoanTerm(int loanTerm) {
        this.loanTerm = loanTerm;
    }

/**
 * Returns the monthly payment for the loan.
 *
 * @return the monthly payment for the loan
 */
    public double getMonthlyPayment() {
        return monthlyPayment;
    }

/**
 * Sets the monthly payment for the loan.
 *
 * @param monthlyPayment the new monthly payment for the loan
 */
    public void setMonthlyPayment(double monthlyPayment) {
        this.monthlyPayment = monthlyPayment;
    }

/**
 * Returns the total payment for the loan.
 *
 * @return the total payment for the loan
 */
    public double getTotalPayment() {
        return totalPayment;
    }

/**
 * Sets the total payment for the loan.
 *
 * @param totalPayment the new total payment for the loan
 */
    public void setTotalPayment(double totalPayment) {
        this.totalPayment = totalPayment;
    }

/**
 * Returns the status of the loan.
 *
 * @return the status of the loan
 */
public String getLoanStatus() {
    return loanStatus;
}

/**
 * Sets the status of the loan.
 *
 * @param loanStatus the new status of the loan
 */
public void setLoanStatus(String loanStatus) {
    this.loanStatus = loanStatus;
}

/**
 * Returns the date the loan was issued.
 *
 * @return the date the loan was issued
 */
public Date getLoanDate() {
    return loanDate;
}

/**
 * Sets the date the loan was issued.
 *
 * @param loanDate the new date the loan was issued
 */
public void setLoanDate(Date loanDate) {
    this.loanDate = loanDate;
}

/**
 * Returns the date the loan was closed.
 *
 * @return the date the loan was closed
 */
public Date getLoanCloseDate() {
    return loanCloseDate;
}

/**
 * Sets the date the loan was closed.
 *
 * @param loanCloseDate the new date the loan was closed
 */
public void setLoanCloseDate(Date loanCloseDate) {
    this.loanCloseDate = loanCloseDate;
}

/**
 * Returns the ID of the loan.
 *
 * @return the ID of the loan
 */
private String getLoanID() {
    return loanID;
}

/**
 * Sets the ID of the loan.
 *
 * @param loanID the new ID of the loan
 */
public void setLoanID(String loanID) {
    this.loanID = loanID;
}

/**
 * Presents the user with a dialog to choose a loan type.
 * Depending on the user's choice, it applies for a loan of the chosen type,
 * or displays the user's loan status.
 *
 * @param user The customer who is choosing a loan type or viewing their loan status.
 * @return The type of loan the user chose to apply for, or null if the user chose to view their loan status or made no valid choice.
 */
    public String chooseLoanType(Customer user) {
        JFrame frame = new JFrame("Choose Loan Type");
        frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        frame.setSize(300, 200);
        frame.setLocationRelativeTo(null);
        frame.setVisible(false);
        String[] options = { "Home Loan", "Car Loan", "Personal Loan", "View Current Loan Status" };
        int choice = JOptionPane.showOptionDialog(frame, "Select the Loan Type:", "Loan Type Selection",
                JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
        switch (choice) {
            case 0:
                applyForLoan("Home Loan", user, frame, bank);
                return null;
            case 1:
                applyForLoan("Car Loan", user, frame, bank);
                return null;
            case 2:
                applyForLoan("Personal Loan", user, frame,bank);
                return null;
            case 3:
                viewLoanStatus(user);
                return null; 
            default:
                frame.dispose(); // Close the frame if no valid choice is made
                return null;
        }
    }
    
/**
 * Initiates the loan application process for a specified customer and loan type. This method handles
 * the entire loan application process, from validating the customer's bank balance to ensure they have
 * enough funds to cover any application fees, to inputting the desired loan amount, selecting the interest
 * rate and term, calculating monthly and total payments, and finally saving the loan application details
 * to a file. It also includes a user interface for input and confirmation dialogs throughout the process.
 * If the application is successful, an application fee is deducted from the customer's account, and the
 * new loan details are added to the customer's list of loans and the method navigates back to the main customer menu using
 * 'bank.showCustomerMenu()'.
 * Additionally, this method simulates loan repayment over the selected term and provides a dialog for the user to top up 
 * their account if the balance is insufficient to cover a monthly payment.
 * 
 *
 * @param loanType The type of loan the customer is applying for.
 * @param user1    The customer applying for the loan. This is used to retrieve the customer's account details.
 * @param frame    The JFrame from which this method is called, allowing the method to close the frame if needed.
 * @param bank     The bank object, allowing access to bank-wide operations such as showing the customer menu.
 *                 This method assumes the existence of methods within the 'account' object to find and retrieve
 *                 customer details, validate and deduct application fees, and to save loan details both to the
 *                 customer's account and to a persistent file. It also assumes a Loan class for creating loan
 *                 objects and setting their details.
 * * Preconditions:
 * - `loanType` must not be null or empty.
 * - `user1` must be a valid, existing customer with a positive bank balance greater than the application fee.
 * - `frame` can be null; if not null, it will be used for displaying dialogs and may be disposed of at the end of the process.
 * - `bank` must be an instance of the Bank class, capable of performing necessary bank operations such as showing customer menus.
 * 
 * Postconditions:
 * - If the customer has sufficient funds and completes the loan application process, a new Loan object will be created and added to the customer's list of loans.
 * - The customer's bank balance will be updated to reflect the deduction of the loan application fee.
 * - A repayment simulation will start, decrementing the customer's bank balance monthly by the monthly payment amount.
 * - The loan application details will be saved to a file named "LoanApplication.txt".
 * - If the customer's balance is insufficient at any repayment period, a dialog for account top-up will be displayed.
 * - Upon successful completion, the loan application status will be shown to the user, and the application fee will be deducted.
 * - The method may terminate early without completing the loan application if the user cancels any of the input dialogs or if initial conditions are not met.
 */
    public void applyForLoan(String loanType, Customer user1, JFrame frame, Bank bank) {
      
       // Account account = new Account();
        Customer user = account.getAccount(user1.getAccountNumber());
        Customer accountCustomer = account.findCustomerByAccountNumber(user.getAccountNumber()); // Assuming findCustomerByAccountNumber is the correct method to retrieve a Customer object based on account number.
        if (accountCustomer != null) {
            double currentBalance = accountCustomer.getBankBalance(); // Retrieve the latest bank balance.
            if (currentBalance <= 0 || currentBalance < APPLICATION_FEE) {
                JOptionPane.showMessageDialog(null, "Insufficient funds to apply for a loan. Please deposit funds and try again.", "Insufficient Funds", JOptionPane.ERROR_MESSAGE);
                return; // Exit the method if funds are insufficient.
            }
            // Proceed with loan application logic if funds are sufficient.
            double loanAmount = 0;
            while (loanAmount <= 0) {
                String loanAmountString = JOptionPane.showInputDialog(null, "Enter the amount to loan out:", "Loan Amount", JOptionPane.QUESTION_MESSAGE);
                if (loanAmountString == null) {
                    // User clicked cancel
                    return;
                }
                if (loanAmountString.matches("\\d+(\\.\\d{1,2})?")) {
                    try {
                        loanAmount = Double.parseDouble(loanAmountString.trim());
                        if (loanAmount <= 0) {
                            JOptionPane.showMessageDialog(null, "Loan amount must be greater than 0. Please enter again:", "Invalid Input", JOptionPane.ERROR_MESSAGE);
                        }
                    } catch (NumberFormatException e) {
                        JOptionPane.showMessageDialog(null, "Invalid input! Please enter a number.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
                    }
                } else {
                    JOptionPane.showMessageDialog(null, "Please enter a number with up to two decimal places.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
                }
            }
            double interestRate = 0;
            int loanTerm = 0;
            while (interestRate <= 0) {
                String[] options = { "2.8% for 12 months", "3.4% for 24 months" };
                int choice = JOptionPane.showOptionDialog(null, "Select the interest rate and term:", "Interest Rate and Term Selection", JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
                if (choice == JOptionPane.CLOSED_OPTION) {
                    // User clicked cancel or closed the dialog
                    return;
                }
                    if (choice == 0) {
                        interestRate = 2.8;
                        loanTerm = 12;
                    } else if (choice == 1) {
                        interestRate = 3.4;
                        loanTerm = 24;
                    }
            }
            // Calculate monthly payment
            double monthlyInterestRate = interestRate / 100 / 12;
            double monthlyPayment = (loanAmount * monthlyInterestRate) / (1 - Math.pow(1 + monthlyInterestRate, -loanTerm));
    
            // Display monthly payment
            JOptionPane.showMessageDialog(null, String.format("Your monthly payment is: $%.2f", monthlyPayment), "Monthly Payment", JOptionPane.INFORMATION_MESSAGE);
            // Calculate and show total payment
            double totalPayment = monthlyPayment * loanTerm;
            JOptionPane.showMessageDialog(null, String.format("Total payment over the life of the loan: $%.2f", totalPayment), "Total Payment", JOptionPane.INFORMATION_MESSAGE);
            // Create a new loan object and add it to the customer's loans
            Loan newLoan = new Loan();
            user.getAccountNumber();
            String loanStatus = "Success";
            newLoan.setLoanStatus(loanStatus);
            String loanID = "L" + (int)(Math.random() * 1000);
            newLoan.setLoanID(loanID);
            newLoan.setLoanType(loanType);
            newLoan.setLoanAmount(loanAmount); // and so on for other properties
            newLoan.setInterestRate(interestRate);
            newLoan.setLoanTerm(loanTerm);
            newLoan.setMonthlyPayment(monthlyPayment);
            newLoan.setTotalPayment(totalPayment);
            newLoan.setLoanDate(new Date());
            newLoan.setLoanCloseDate(new Date());
            user.addLoan(newLoan); 

            // Save the loan application to a file
            String filename = "LoanApplication.txt";
            try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename, true))) { // true for append mode
                writer.write("Loan Application\n");
                writer.write("Account Number: " + user.getAccountNumber() + "\n");
                writer.write("Loan Status: " + loanStatus + "\n");
                writer.write("Loan ID: " + loanID + "\n");
                writer.write("Loan Type: " + loanType + "\n");
                writer.write("Loan Amount: $" + loanAmount + "\n");
                writer.write("Interest Rate: " + interestRate + "%\n");
                writer.write("Loan Term: " + loanTerm + " months\n");
                writer.write("Monthly Payment: $" + String.format("%.2f", monthlyPayment) + "\n");
                writer.write("Total Payment: $" + String.format("%.2f", totalPayment) + "\n");
                writer.write("Loan Date: " + loanDate.toString() + "\n");
                writer.write("Loan Close Date: " + loanCloseDate.toString() + "\n");
                writer.write("\n"); // Add a blank line between loan applications
            } catch (IOException e) {
                JOptionPane.showMessageDialog(null, "Error saving loan application to file.", "Error", JOptionPane.ERROR_MESSAGE);
            }
            // Deduct application fee from the account
            account.deductApplicationFee(user, APPLICATION_FEE);
            JOptionPane.showMessageDialog(null, "Application fee of " + APPLICATION_FEE + " has been deducted from the account!", "Success", JOptionPane.INFORMATION_MESSAGE);
            JOptionPane.showMessageDialog(null, "Loan application for " + loanType + " submitted successfully!", "Success", JOptionPane.INFORMATION_MESSAGE);
            
        if (frame != null) {
        frame.dispose();
        }
        // Return to the main menu
        bank.showCustomerMenu();

           // Start the loan repayment simulation
           final int[] timeElapsed = new int[] {loanTerm};
           Timer timer = new Timer(1000, null); // Fires every 1000 ms (1 second) for simulation purposes

           timer.addActionListener(e -> {
           timeElapsed[0]--; // Decrement months remaining

           if (timeElapsed[0] <= 0) {
               // Stop the timer and calculate final maturity
               timer.stop();
               JOptionPane.showMessageDialog(null, "Your loan has been fully repaid.");
           } else {
               // Check if account balance is less than monthly payment
               while (accountCustomer.getBankBalance() < monthlyPayment) {
               // Create a custom dialog
               JDialog dialog = new JDialog(frame, "Top Up", true);
               dialog.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);

               // Create a JPanel with BoxLayout
               JPanel panel = new JPanel();
               panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
               dialog.add(panel);

               JLabel label = new JLabel(String.format("<html>Insufficient funds.<br>Current balance: $%.2f<br>Monthly repayment: $%.2f<br>Please top up your account:</html>", accountCustomer.getBankBalance(), monthlyPayment));
               panel.add(label);

               JTextField textField = new JTextField(10);
               panel.add(textField);

               JButton button = new JButton("Top Up");
               button.addActionListener(e1 -> {
               try {
                   double topUpAmount = Double.parseDouble(textField.getText().trim());
               if (topUpAmount <= 0) {
                   JOptionPane.showMessageDialog(null, "Top up amount must be greater than 0. Please enter again:", "Invalid Input", JOptionPane.ERROR_MESSAGE);
               } else {
                   accountCustomer.setBankBalance(accountCustomer.getBankBalance() + topUpAmount); // Top up the account
                   dialog.dispose();
                }
               } catch (NumberFormatException ex) {
                   JOptionPane.showMessageDialog(null, "Invalid input! Please enter a number.", "Invalid Input", JOptionPane.ERROR_MESSAGE);
               }
           });

               panel.add(button);
               dialog.pack();
               dialog.setLocationRelativeTo(frame); // to center the dialog
               dialog.setVisible(true);
           }           
               // Deduct loan payment from bank balance
               double newBalance = accountCustomer.getBankBalance() - monthlyPayment;
               accountCustomer.setBankBalance(newBalance);
               customer.setBankBalance(newBalance); // Update the balance in the Account object
               account.updateCustomerDataFile(user.getAccountNumber(),"Bank Balance", String.format("%.2f", newBalance));
               account.getAccList().clear();
               account.loadFromFile();

               // Optionally update the user on the status here
               System.out.println("Month passed in simulation. " + timeElapsed[0] + " months remaining.");
               System.out.println("Loan payment deducted. New balance: " + String.format("%.2f", newBalance));
           }
       });
               timer.start(); // Start the timer
        }

    }

/**
 * Loads and parses loan applications from a specified file for a given account number.
 * This method reads a text file named "LoanApplication.txt", searching for loan applications
 * that match the provided account number. Each loan application is expected to be separated
 * by a "Loan Application" header, with various details following it, including the account number
 * in the format "Account Number: [accountNumber]". When a matching application is found,
 * it is parsed and added to a list of {@link Loan} objects, which is then returned.
 *
 * @param accountNumber The account number for which loan applications are to be loaded.
 * @return A list of {@link Loan} objects corresponding to the loan applications found for
 *         the specified account number. If no matching applications are found, returns an empty list.
 * @throws FileNotFoundException If the file "LoanApplication.txt" cannot be found.
 * @throws IOException If an error occurs during reading from the file.
 */
    public List<Loan> loadLoansForAccount(String accountNumber) throws FileNotFoundException, IOException {
        List<Loan> loansForAccount = new ArrayList<>();
        String filename = "LoanApplication.txt"; 
    
        try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
            String line;
            // Check if the current loan application belongs to the account
            boolean isCurrentApplicationForAccount = false;
            List<String> loanDataLines = new ArrayList<>();
    
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("Loan Application")) {
                    // Process the previous loan application if it belongs to the account
                    if (isCurrentApplicationForAccount) {
                        Loan loan = parseLoanApplication(loanDataLines);
                        loansForAccount.add(loan);
                    }
                    // Reset for the next loan application
                    isCurrentApplicationForAccount = false;
                    loanDataLines.clear();
                } else if (line.startsWith("Account Number: ")) {
                    String currentAccountNumber = line.split(": ")[1].trim();
                    if (currentAccountNumber.equals(accountNumber)) {
                        isCurrentApplicationForAccount = true;
                    }
                }
                if (isCurrentApplicationForAccount) {
                    loanDataLines.add(line);
                }
            }
    
            // Check and process the last loan application in the file
            if (isCurrentApplicationForAccount) {
                Loan loan = parseLoanApplication(loanDataLines);
                loansForAccount.add(loan);
            }
    
        } catch (FileNotFoundException e) {
            System.out.println("File not found: " + filename);
        } catch (IOException e) {
            System.out.println("An error occurred while reading the file.");
        }
        System.out.println("Loans for account: " + loansForAccount.size() + " loans found.");
        System.out.println("Loans for account: " + accountNumber + " loans found.");

        return loansForAccount;
    }

/**
 * Parses loan application data from a list of strings and populates a {@link Loan} object.
 * Each string in the list is expected to represent a specific attribute of the loan application,
 * such as the account number, loan status, loan ID, and other financial and temporal details.
 * This method systematically checks each line for key identifiers (e.g., "Loan Amount:", "Interest Rate:")
 * and assigns the corresponding values to the relevant fields of a {@link Loan} object.
 * 
 * The method handles parsing of numerical values (such as loan amount and interest rate)
 * and date values (such as loan date and loan close date) with specific formats.
 * Errors during parsing or incorrect data formats are caught and handled by printing the stack trace.
 * 
 * @param loanDataLines A list of strings, each containing a line of the loan application data.
 * @return A {@link Loan} object populated with the data parsed from the input list.
 *         If parsing fails or data is invalid, the returned {@link Loan} object's state
 *         may not be fully initialized.
 */
    private Loan parseLoanApplication(List<String> loanDataLines) {
        SimpleDateFormat dateFormat = new SimpleDateFormat("E MMM dd HH:mm:ss z yyyy");
        Loan loan = new Loan(); // Assuming a no-argument constructor is available
        Customer user = new Customer();
        try {
            for (String line : loanDataLines) {
                if (line.startsWith("Account Number: ")) {
                    user.setAccountNumber(line.substring(line.indexOf(":") + 1).trim());
                } else if (line.startsWith("Loan Status: ")) {
                    loan.setLoanStatus(line.substring(line.indexOf(":") + 1).trim());
                } else if (line.startsWith("Loan ID: ")) {
                    loan.setLoanID(line.substring(line.indexOf(":") + 1).trim());
                } else if (line.startsWith("Loan Type: ")) {
                    loan.setLoanType(line.substring(line.indexOf(":") + 1).trim());
                } else if (line.startsWith("Loan Amount: $")) {
                    loan.setLoanAmount(Double.parseDouble(line.substring(line.indexOf("$") + 1).trim()));
                } else if (line.startsWith("Interest Rate: ")) {
                    loan.setInterestRate(Double.parseDouble(line.substring(line.indexOf(":") + 1, line.indexOf("%")).trim()));
                } else if (line.startsWith("Loan Term: ")) {
                    loan.setLoanTerm(Integer.parseInt(line.substring(line.indexOf(":") + 1, line.indexOf("months")).trim()));
                } else if (line.startsWith("Monthly Payment: $")) {
                    loan.setMonthlyPayment(Double.parseDouble(line.substring(line.indexOf("$") + 1).trim()));
                } else if (line.startsWith("Total Payment: $")) {
                    loan.setTotalPayment(Double.parseDouble(line.substring(line.indexOf("$") + 1).trim()));
                } else if (line.startsWith("Loan Date: ")) {
                    loan.setLoanDate(dateFormat.parse(line.substring(line.indexOf(":") + 1).trim()));
                } else if (line.startsWith("Loan Close Date: ")) {
                    loan.setLoanCloseDate(dateFormat.parse(line.substring(line.indexOf(":") + 1).trim()));
                }
            }
        } catch (Exception e) {
            e.printStackTrace(); // Handle parsing errors or invalid data formats
        }

        return loan;
    }

/**
 * Updates the loan information for a given customer by loading the latest loan data from a data source.
 * This method attempts to load loans associated with the customer's account number and updates the
 * customer's loan list with the newly loaded data. It ensures that the customer's loan information
 * is current and reflects any changes or updates that may have occurred in the data store.
 * 
 * The method {@code loadLoansForAccount} is used to retrieve the loans, which should return a list of
 * {@code Loan} objects corresponding to the customer's account. Upon successful loading of loans,
 * the customer's loan list is updated through the {@code setLoans} method of the {@code Customer} class.
 * 
 * Exception Handling:
 * - {@code FileNotFoundException} is caught and handled if the data source for the loans cannot be found.
 * - {@code IOException} is caught and handled if there's an issue reading from the data source.
 * 
 * @param customer The {@code Customer} whose loans are to be updated. This object must have a valid
 *                 account number and be capable of holding a list of {@code Loan} objects.
 */
    public void updateCustomerLoans(Customer customer) {
        try {
            // Load and update the customer's loans
            List<Loan> loadedLoans = loadLoansForAccount(customer.getAccountNumber());
            customer.setLoans(loadedLoans); // Make sure Customer class has this method to update loans
        } catch (FileNotFoundException e) {
            e.printStackTrace(); // Handle file not found exception
        } catch (IOException e) {
            e.printStackTrace(); // Handle IO exception
        }
    }
    
  /**
 * Displays the loan status for a specified customer. This method first updates the customer's
 * loan information by calling {@code updateCustomerLoans(Customer customer)}, which loads
 * and parses loan applications from a file, matching the customer's account number. After
 * updating the loans, it utilizes an instance of the {@link Loan} class to invoke
 * {@code viewLoanStatus(Customer customer)}, which is responsible for displaying the status
 * of each loan associated with the customer.
 *
 * Note: This method assumes that the {@link Loan} class has a method named
 * {@code viewLoanStatus(Customer customer)} that displays loan status information for a given
 * customer. It is also implied that the customer object passed to this method is properly
 * initialized with an account number and that the {@link Customer} class has a mechanism
 * to store and access loan information.
 *
 * @param customer The customer whose loan status is to be displayed. This customer's loan
 *                 information will be updated based on matching loan applications found in
 *                 the "LoanApplication.txt" file before displaying the loan status.
 */
    public void showCustomerLoanStatus(Customer customer) {
    updateCustomerLoans(customer); // Load and update the customer's loans
    // Now call viewLoanStatus with updated loans
    new Loan().viewLoanStatus(customer); 
    }

/**
 * Displays the status of all loans associated with a specified customer.
 * This method retrieves the current loan information for the customer from the data store
 * by calling {@code updateCustomerLoans(user)}, then compiles a detailed report of each loan's
 * status. The report includes the account number, loan ID, loan status, loan type, loan amount,
 * interest rate, loan term, monthly payment, total payment, loan start date, and loan close date.
 * 
 * The loan status report is displayed in a scrollable text area within a dialog box, allowing
 * the user to review all loan details at once. This method is designed to provide customers
 * with comprehensive visibility into their loan statuses, facilitating better financial management
 * and planning.
 * 
 * 
 * @param user The {@code Customer} whose loan status is to be viewed. This parameter must not be null.
 */
    public void viewLoanStatus(Customer user) {
        updateCustomerLoans(user); // Update the customer's loans from the data store
        // Display the loan status
        StringBuilder loanStatusText = new StringBuilder();
        for (Loan loan : user.getLoans()) {
            loanStatusText.append("Account Number: ").append(user.getAccountNumber()).append("\n")
                          .append("Loan ID: ").append(loan.getLoanID()).append("\n")
                          .append("Loan Status: ").append(loan.getLoanStatus()).append("\n")
                          .append("Loan Type: ").append(loan.getLoanType()).append("\n")
                          .append("Loan Amount: ").append(loan.getLoanAmount()).append("\n")
                          .append("Interest Rate: ").append(loan.getInterestRate()).append("\n")
                          .append("Loan Term: ").append(loan.getLoanTerm()).append("\n")
                          .append("Monthly Payment: ").append(loan.getMonthlyPayment()).append("\n")
                          .append("Total Payment: ").append(loan.getTotalPayment()).append("\n")
                          .append("Loan Date: ").append(loan.getLoanDate()).append("\n")
                          .append("Loan Close Date: ").append(loan.getLoanCloseDate()).append("\n\n");
        }
            // Display the loan status in a scrollable text area
        JTextArea textArea = new JTextArea(loanStatusText.toString());
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);
        scrollPane.setPreferredSize(new Dimension(500, 500));

        JOptionPane.showMessageDialog(null, scrollPane, "Loan Status", JOptionPane.INFORMATION_MESSAGE);
    }
    
/* 
    public void startLoanPayment() {
        if ("Approved".equals(this.loanStatus)) {
            // Logic to start payment
            // For example, update status to indicate payment has started
            this.loanStatus = "Payment Started";
            System.out.println("Loan payment process has started for Loan ID: " + this.loanID);
        } else {
            System.out.println("Loan payment cannot start as the loan is not approved.");
        }
    }
    
    public void deductLoanPayment(Customer user) {
        Customer customer = user; // Assuming user is the customer who applied for the loan
        Account customerAccount = findCustomerAccount(user); // Method to find customer's account
        if (customerAccount != null && "Approved".equals(this.loanStatus)) {
            double currentBalance = customer.getBankBalance(); 
            if (currentBalance >= monthlyPayment) {
                double deduction = customer.getBankBalance() - monthlyPayment; // Calculate the new balance
                customer.setBankBalance(deduction); // Deduct the monthly payment from the account
                System.out.println("Monthly loan payment of " + monthlyPayment + " has been deducted from the account.");
                // Optionally, update account and loan details in the data store here
            } else {
                System.out.println("Insufficient funds for loan payment deduction.");
                // Handle insufficient funds case, e.g., notify customer, apply fees, etc.
            }
        } else {
            System.out.println("Customer account not found or loan not approved.");
        }
    }

    public Account findCustomerAccount(Customer user) {
        Account account = new Account(); // Assuming Account class instantiation
        Customer accountCustomer = account.findCustomerByAccountNumber(customer.getAccountNumber());
        if (accountCustomer != null) {
            // Now you have the customer details, proceed as needed
            return account; // Adjust this return statement based on your actual logic and method signatures
        }
        return null;
    }

        public void saveLoanStatusToFile() {
        String loanStatus = getLoanStatus();
        try {
            PrintWriter out = new PrintWriter(new FileOutputStream("LoanApplication.txt"));
            out.println(loanStatus);
            out.close();
        } catch (FileNotFoundException e) {
            System.out.println("File not found.");
        }
    }
    */
} 

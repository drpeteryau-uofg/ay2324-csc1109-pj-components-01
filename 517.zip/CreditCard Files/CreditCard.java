
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.text.DecimalFormat;
import java.time.LocalDate;
import java.util.Random;

/**
 * The Credit Card class for bank usage
 *
 * @author Ambrose Goh
 * @author Bryan
 * @version 1.0, 3 March 2024
 */
public class CreditCard {

    private final int accountId;
    private final long paymentCardNumber;
    private final int cvv;
    private int cardPin; // For drawing money using credit card since credit card information is on the credit card itself
    private BigDecimal dailyLimit;
    private BigDecimal creditLimit;
    private final LocalDate expiryDate;
    private BigDecimal outstandingPayment;

    public CreditCard(int accountId, long paymentCardNumber, int cvv, LocalDate expiryDate) {
        this.accountId = accountId;
        this.paymentCardNumber = paymentCardNumber;
        this.cvv = cvv;
        this.dailyLimit = BigDecimal.valueOf(5000); // Default
        this.creditLimit = BigDecimal.ZERO;
        // Creditor needs to update credit card limit
        this.expiryDate = expiryDate;
        this.outstandingPayment = BigDecimal.ZERO;
    }

    /**
     * Generates a random 3 digit int
     *
     * @return int of 3 digit int
     */
    public static int generateCVV() {
        Random rand = new Random();
        return rand.nextInt(899) + 100;
    }

    /**
     * Takes in BigDecimal value and converts to 2dp string
     *
     * @param bd
     * @return string of bd with 2 dp
     */
    public static String getBigDecimal2DP(BigDecimal bd) {
        bd = bd.setScale(2, RoundingMode.HALF_EVEN);
        DecimalFormat df = new DecimalFormat();
        df.setMaximumFractionDigits(2);
        df.setMinimumFractionDigits(0);
        df.setGroupingUsed(false);
        return df.format(bd);
    }

    /**
     * Checks if cvv is equals to the credit card's cvv
     *
     * @param cvv
     * @return true if cvv is equals to the credit card's cvv and false otherwise
     */
    public boolean isCVVValid(int cvv) {
        return this.cvv == cvv;
    }

    public boolean isCardPinValid(int cardPin) {
        return this.cardPin == cardPin;
    }

    public boolean isCardPinFormatValid(int cardPin) {
        return Integer.toString(cardPin).length() == 6;
    }

    /**
     * Checks if expiry date is equals to the credit card's expiry date
     *
     * @param expiryDate
     * @return true if expiry date is equals to the credit card's expiry date and false otherwise
     */
    public boolean isCreditCardExpiryDateValid(LocalDate expiryDate) {
        return this.expiryDate.equals(expiryDate);
    }

    /**
     * Checks if current date is after the credit card's expiry date
     *
     * @return true if current date is after the credit card's expiry date and false otherwise
     */
    public boolean isCreditCardExpired() {
        return LocalDate.now().isAfter(expiryDate);
    }

    /**
     * Checks if amt + outstanding payment is less than the credit limit
     *
     * @return true if amt + outstanding payment is less than the credit limit and false otherwise
     */
    public boolean isOutstandingPaymentValid(BigDecimal amt) {
        return outstandingPayment.add(amt).compareTo(creditLimit) < 0;
    }

    /**
     * Checks if amt to be paid is less than the monthly limit
     *
     * @return true if amt to be paid is less than the monthly limit and false otherwise
     */
    public boolean isMonthlyLimitValid(BigDecimal amt) {
        return amt.compareTo(dailyLimit) < 0;
    }

    /**
     * @return bank account number associated to this credit card
     */
    public int getAccountId() {
        return accountId;
    }

    /**
     * @return payment card number (~16 pins of a credit card)
     */
    public long getPaymentCardNumber() {
        return paymentCardNumber;
    }

    /**
     * @return cvv of a credit card (3 pin)
     */
    public int getCvv() {
        return cvv;
    }

    /**
     * @return card pin of a credit card (3 pin)
     */
    public int getCardPin() {
        return cardPin;
    }

    public void setCardPin(int cardPin) {
        this.cardPin = cardPin;
    }

    /**
     * @return daily limit of the credit card
     */
    public BigDecimal getDailyLimit() {
        return dailyLimit;
    }

    /**
     * @param dailyLimit daily limit to be set
     */
    public void setDailyLimit(BigDecimal dailyLimit) {
        this.dailyLimit = dailyLimit;
    }

    /**
     * @return credit limit of the credit card
     */
    public BigDecimal getCreditLimit() {
        return creditLimit;
    }

    /**
     * @param creditLimit credit limit to be set
     */
    public void setCreditLimit(BigDecimal creditLimit) {
        this.creditLimit = creditLimit;
    }

    /**
     * @return expiry date of the credit card
     */
    public LocalDate getExpiryDate() {
        return expiryDate;
    }

    /**
     * @return outstanding payment amt of the credit card
     */
    public BigDecimal getOutstandingPayment() {
        return outstandingPayment;
    }

    /**
     * @param amt outstanding amount to be set
     */
    public void setOutstandingPayment(BigDecimal amt) {
        this.outstandingPayment = amt;
    }


    // Application layer

    /**
     * updates the credit limit of the credit card based on the customer's age and annual income
     *
     * @param age          The age of the customer
     * @param annualIncome The annual income of the customer
     */
    public void updateCreditLimit(int age, BigDecimal annualIncome) {
        if (age < 21 || age > 70) {
            this.creditLimit = BigDecimal.ZERO;
        } else if (age > 55 && annualIncome.compareTo(BigDecimal.valueOf(15000)) < 0) {
            this.creditLimit = BigDecimal.valueOf(2500);
        } else if (age > 55 && annualIncome.compareTo(BigDecimal.valueOf(30000)) < 0) {
            this.creditLimit = annualIncome
                    .divide(BigDecimal.valueOf(12), 2, RoundingMode.HALF_EVEN)
                    .multiply(BigDecimal.valueOf(2));
        } else if (annualIncome.compareTo(BigDecimal.valueOf(120000)) < 0) {
            this.creditLimit = annualIncome
                    .divide(BigDecimal.valueOf(12), 2, RoundingMode.HALF_EVEN)
                    .multiply(BigDecimal.valueOf(4));
        } else {
            this.creditLimit = annualIncome;
        }
    }

    public void updateCreditLimit(int creditScore) {

    }

    /**
     * Takes in credit card information and amount for payment and updates if payment is success or fail
     *
     * @param paymentCardNumber the credit card's payment card number
     * @param cvv               the credit card's cvv
     * @param expiryDate        the credit card's expiry date
     * @param amt               the amount needed to be paid
     */
    public void useCreditCard(long paymentCardNumber, int cvv, LocalDate expiryDate, BigDecimal amt) {

        // check credit card details are valid
        if (false) { // if paymentCardNumber (credit card) does not exist
            System.out.println("Credit card does not exist!");
            return;
        }
        if (!isCVVValid(cvv)) {
            System.out.println("Invalid cvv input");
            return;
        }
        if (!isCreditCardExpiryDateValid(expiryDate)) {
            System.out.println("Invalid expiry date input");
            return;
        }

        // Check if payment is declined
        if (!isMonthlyLimitValid(amt)) {
            System.out.println("Credit card payment declined: Monthly limit exceeded");
            return;
        }
        if (!isOutstandingPaymentValid(amt)) {
            System.out.println("Credit card payment declined: Outstanding payment exceeded credit limit");
            return;
        }
        if (isCreditCardExpired()) {
            System.out.println("Credit card payment declined: Credit card is expired!");
            return;
        }

        setOutstandingPayment(getOutstandingPayment().add(amt));
        System.out.println("Credit Card: " + paymentCardNumber + ", " + "Made payment of: " + getBigDecimal2DP(amt));
    }

    /**
     * Takes in current card pin and new card pin.
     * Changes the card pin of the credit card if both current card pin and new card pin is valid
     *
     * @param cardPin    cardPin card pin is "password" of the credit card
     * @param newCardPin the new card pin set on the credit card
     */
    public void changeCardPin(int cardPin, int newCardPin) {
        if (!isCardPinValid(cardPin)) {
            System.out.println("Inputted current card pin is invalid!");
            return;
        }
        if (!isCardPinFormatValid(cardPin)) {
            System.out.println("Card Pin format is invalid!");
            return;
        }
        setCardPin(newCardPin);
    }

}

//import hashmap
import java.util.HashMap;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;


public class FX{ 
    private Map<String, Double> exchangeRates = new HashMap<>();
    private Map<String, double[]> foreignBal;

     /**
     * Constructor for FX class to read the rates.csv file and
     * @param filename
     * @param filename2
     * @param accountID
     */
    public FX(String ratesFile, String foreignBalFile, String accountID){
        foreignBal = new HashMap<>();
        exchangeRates = new HashMap<>();
        readRatesCSV(ratesFile);
        readForeignBalanceCSV(foreignBalFile, accountID);
    }

    /**
     * void method to read the rates.csv file and store the currency name and rates in a hashmap called exchangeRates  
     * @param filename the name of the file to be read 
     */
    public void readRatesCSV(String filename){
        try{BufferedReader ratesYoinker = new BufferedReader(new FileReader(filename));
            String line;
            ratesYoinker.readLine(); //skip the first line
            while((line = ratesYoinker.readLine()) != null){
                String [] data = line.split(",");
                exchangeRates.put(data[0], Double.parseDouble(data[1]));
            }
        }catch(IOException e){
            e.printStackTrace();
        }
    }

    /**
     * double method to get the currency rate from the hashmap exchangeRates
     * @param currency This is the currency selected by the user or system
     * @return the currency rate from the hashmap exchangeRates
     */
    public double getCurrencyRate(String currency){
        if(exchangeRates.containsKey(currency)){
            return exchangeRates.get(currency);
        }
        else{   
            return 0.0;
        }
    }

    /**
     * ArrayList method to get the currency name from the hashmap exchangeRates
     * @return the currency name from the hashmap exchangeRates
     */
    public ArrayList<String> getCurrencyName(){
        ArrayList<String> currencyName = new ArrayList<>();
        for(String currencyNameKey : exchangeRates.keySet()){
            currencyName.add(currencyNameKey);
        }
        return currencyName;
    }

    /**
     * void method to read the foreignBalance.csv file and store the accountID and balances in a hashmap called foreignBal
     * foreignBal is a hashmap with the accountID as the key and the balances as the value
     * @param foreignBalFilePath the name of the file to be read
     * @param accountID the accountID of the user
     */
    public void readForeignBalanceCSV(String foreignBalFilePath, String accountID) {
        try (BufferedReader foreignYoinker = new BufferedReader(new FileReader(foreignBalFilePath))) {
            String line;
            while ((line = foreignYoinker.readLine()) != null) {
                String[] parts = line.split(",");
                String currentAccountID = parts[0].trim();
                if (currentAccountID.equals(accountID)) {
                    double[] balances = new double[parts.length - 1];
                    for (int i = 1; i < parts.length; i++) {
                        balances[i - 1] = Double.parseDouble(parts[i].trim());
                    }
                    foreignBal.put(accountID, balances);
                    return;
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    /**
     * double method to get the account foreign balances from the hashmap foreignBal
     * 0 = USD, 1 = EUR, 2 = JPY, 3 = GBP, 4 = AUD, 5 = CNY
     * @param accountID the accountID of the user
     * @param currencyName the currency selected by the user or system
     * @return the account foreign balances from the hashmap foreignBal
     */
    public double getAccountForeignBalances(String accountID, String currencyName) {
        if (foreignBal.containsKey(accountID)) {
            double[] balances = foreignBal.get(accountID);
            // 0 = USD, 1 = EUR, 2 = JPY, 3 = GBP, 4 = AUD, 5 = CNY
            // IF ITS DIFFERENT GG, DONT CHANGE FORMAT
            switch (currencyName) {
                case "USD":
                    return balances[0];
                case "EUR":
                    return balances[1];
                case "JPY":
                    return balances[2];
                case "GBP":
                    return balances[3];
                case "AUD":
                    return balances[4];
                case "CNY":
                    return balances[5];
                default:
                    System.out.println("Currency not found.");
                    return -1.0; // -1.0 is used to indicate that the currency is not found if 0.0 is used, it will be ambiguous
            }
        } 
        else {
            System.out.println("Account ID not found.");
            return -1.0; // -1.0 is used to indicate that the account ID is not found if 0.0 is used, it will be ambiguous
        }
    }
    
    /**
     * double method to convert the amount to SGD
     * @param amount the amount to be converted
     * @param currency the currency selected by the user or system
     * @return the amount converted to SGD, use this to add to the balance
     */
    public double convertToSGD(double amount, String currency){
        double rates = 0.0;
        rates = getCurrencyRate(currency);
        return amount * rates * 0.98; //2% HIDDEN TAX BABY
    }
    
    /**
     * void method to deduct the foreign balance from the account
     * @param accountID the accountID of the user
     * @param currency the currency selected by the user or system
     * @param amount the amount to be deducted
     */
    public void deductForeignBalance(String accountID, String currency, double amount){
        double[] foreignBalances = foreignBal.get(accountID);
        if(foreignBalances != null){
            switch(currency){
                case "USD":
                    foreignBalances[0] -= amount;
                    System.out.println(foreignBalances[0]);
                    break;
                case "EUR":
                    foreignBalances[1] -= amount;
                    System.out.println(foreignBalances[1]);
                    break;
                case "JPY":
                    foreignBalances[2] -= amount;
                    System.out.println(foreignBalances[2]);
                    break;
                case "GBP":
                    foreignBalances[3] -= amount;
                    System.out.println(foreignBalances[3]);
                    break;
                case "AUD":
                    foreignBalances[4] -= amount;
                    System.out.println(foreignBalances[4]);
                    break;
                case "CNY":
                    System.out.println(foreignBalances[5]);
                    foreignBalances[5] -= amount;
                    break;
                default:
                    break;
            }
        }
    }

    //tester
    // public static void main(String[] args){
    // }
}

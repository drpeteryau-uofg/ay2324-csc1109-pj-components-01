/*
Sub class without main method.
Objects of sub class will be created in Bank.java master class. 
*/

public class Account {
        private String accountNumber;

        // Getter.
        public String getAccountNumber() {
                return this.accountNumber;
        }

        // Setter.
        public void setAccountNumber(String newAccountNumber) {
                this.accountNumber = newAccountNumber;
        }
}

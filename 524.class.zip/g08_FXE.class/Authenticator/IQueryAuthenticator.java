package Authenticator;
/**
 * Inteface for requesting information from an autheticator
 */
public interface IQueryAuthenticator
{
    /**
     * Requests the user id which has been authenticated by the authenticator after the user successfully logged into the app.
     * @return User's unique identification as string.
     */
    public String getAuthenticatedUserID();
}
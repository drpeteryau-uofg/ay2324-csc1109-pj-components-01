/*
Master class with main method.
*/
import ForeignExchange.*;

public class Bank {
        // Main method.
        public static void main(String[] args) {
                // Objects of sub classes.
                Account account = new Account();
                Customer customer = new Customer();
                // ForeignExchange fx = new ForeignExchange();
                Insurance insurance = new Insurance();
                Branch branch = new Branch();

        }
}
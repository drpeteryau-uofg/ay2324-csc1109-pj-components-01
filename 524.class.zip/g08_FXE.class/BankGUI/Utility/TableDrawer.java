package BankGUI.Utility;

import java.util.Arrays;
import java.util.stream.Collectors;

public class TableDrawer
{

    /**
     * String[][] table = { { " ID ", " Name ", " Age " }, { " 1 ", " John ", " 24 "
     * }, { " 2 ", " Jeff ", " 19 " }, { " 3 ", " Joel ", " 42 " } };
     * System.out.println(drawTable(table));
     * 
     * @param table Is a 2D string array that represents the rows and columns of the
     * table
     * @return Returns a string with the table drawn
     * @see https://tio.run/##lZPfT4MwEMff@SsuPEHcOjd9MYsmi75oog/q29xDgY4VS0vaMrJM/nZsx68YcNE@lON6n959jyPBezxNos@qomkmpIbEOFCuKUMrKfFBLZ3BgdKS4BTdC8ZIqIU0MU6WB4yGEDKsFDxjyuHogFmNX2mszeNNS8pjiCQu3nHAiFc71pv1BrR1@A1mVxMcCBkR@SoKuIW6pKYA70SsLzd@h7RrNmswkIYLiC4I4dZWg1CU4swzF8L0DtypiyTJCNbWgxjhsd55vj9MgMJavNc3ASWCclOw5164E2i2D@76/rLDJdG55GMyRjWcTk4SCqp3jSTV6QkJY78IsowR9DORcQ7T/EnRlxVTbydF/2tI9wUnMGa2DSqdkYnZCxpBauapGxXAMlbDOelnyMzJcVDf0QV4fACwGgBecEqgfVnFxnbLySgD8zbsSex4x8Di@gyz6Biy3fbM/OYMc9XnIaxnru1dZbl0erkHpUmKRK5RZoRrxr3@f6pnqWtoWVXf
     */
    public static String drawTable(String[][] table)
    {
        String borderRow = Arrays.stream(table[0])
                // border row between rows
                .map(str -> "-".repeat(str.length())).collect(Collectors.joining("+", "+", "+\n"));
        return Arrays.stream(table)
                // table row with borders between cells
                .map(row -> Arrays.stream(row).collect(Collectors.joining("|", "|", "|\n")))
                .collect(Collectors.joining(borderRow, borderRow, borderRow));

    }
}

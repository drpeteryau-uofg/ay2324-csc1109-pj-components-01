/*
Sub class without main method.
Objects of sub class will be created in Bank.java master class. 
*/

public class Branch {
        private String test;

        // Getter.
        public String getTest() {
                return this.test;
        }

        // Setter.
        public void setTest(String newTest) {
                this.test = newTest;
        }
}

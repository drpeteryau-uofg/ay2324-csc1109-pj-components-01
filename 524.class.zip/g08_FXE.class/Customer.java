/*
Sub class without main method.
Objects of sub class will be created in Bank.java master class. 
*/

public class Customer {
        private String customerName;

        // Getter.
        public String getCustomerName() {
                return this.customerName;
        }

        // Setter.
        public void setCustomerName(String firstName, String lastName) {
                this.customerName = firstName.concat(lastName);
        }
}

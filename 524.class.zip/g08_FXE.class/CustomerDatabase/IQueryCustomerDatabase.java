package CustomerDatabase;
/**
 * Inteface for requesting information from a customer database
 */
public interface IQueryCustomerDatabase
{

    /**
     * Gets the account IDs which belongs to the customer with the customerID.
     * 
     * @param customerID The String id of the customer currently using the bank
     * application
     * @return Array of Account IDs belonging to the customer of customerID. Returns
     * null if customerID does not exist.
     */
    public String[] getCustomerAccountIDs(String customerID);

    /**
     * Tries to withdraw an amount from the account with the accountID belonging to
     * the customer with the customerID.
     * 
     * @param customerID The String id of the customer currently using the bank
     * application
     * @param accountID The String id of the account that the customer wants to
     * withdraw from.
     * @param amount The withdrawal amount. 
     * @return true if withdrawal is successful else false..
     */
    public boolean withdrawAmount(String customerID, String accountID, float amount);

    /**
     * Tries to deposit an amount from the account with the accountID belonging to
     * the customer with the customerID.
     * 
     * @param customerID The String id of the customer currently using the bank
     * application
     * @param accountID The String id of the account that the customer wants to
     * deposit into.
     * @param amount The deposit amount. 
     * @return true if deposit is successful else false..
     */
    public boolean depositAmount(String customerID, String accountID, float amount);


    /**
     * Retrieves the current balance of an account given the accountiD of the customer with customerrID
     * @param customerID The String id of the customer currently using the bank
     * application
     * @param accountID The String id of the account that the customer wants to
     * deposit into.
     * @return The current balance in that account
     */
    public float getBalanceFromAccount(String customerID, String accountID);

}
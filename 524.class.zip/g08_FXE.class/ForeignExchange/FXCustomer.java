package ForeignExchange;

import CustomerDatabase.IQueryCustomerDatabase;

import java.util.Arrays;
import java.util.HashMap;

public class FXCustomer {
    final private int MAX_CURRENCY_NUMBER = 3;
    final private String BASE_CURRENCY = "SGD";
    private String customerID;
    private String[] currencies = new String[MAX_CURRENCY_NUMBER];
    private String[] balances = new String[MAX_CURRENCY_NUMBER];
    private String maxCurrency;
    private boolean inDB;
    private IQueryCustomerDatabase databaseConnection;

    //<editor-fold desc="Getter and Setters">
    public FXCustomer(String customerID, IQueryCustomerDatabase queryCustomerDatabase, ReadFXCustomerInfoCSV readFXCustomerInfoCSV){
        this.customerID = customerID;
        this.databaseConnection = queryCustomerDatabase;
        initialiseCustomer(readFXCustomerInfoCSV);
    }

    public String getCustomerID(){
        return customerID;
    }

    public String getCurrencies(int index){
        return currencies[index];
    }

    public String[] getCurrenciesArray(){
        return currencies;
    }

    public void setCurrencies(int index, String currency){
        currencies[index] = currency;
    }

    public float getBalances(String currency){
        return Float.parseFloat(balances[currencyIndex(currency)]);
    }

    public String[] getBalancesArray(){
        return balances;
    }

    public String getMaxCurrency(){
        return maxCurrency;
    }

    private void updateMaxCurrency(){
        // Updates the maxCurrency value based on if empty currency slot exists
        maxCurrency = "TRUE";
        for (int i = 0; i < MAX_CURRENCY_NUMBER; i++) {
            if (getCurrencies(i).isEmpty()) {
                maxCurrency = "FALSE";;
                break;
            }
        }
    }

    public boolean hasCurrency(String currency){
        return Arrays.asList(currencies).contains(currency);
    }

    public int currencyIndex(String currency){
        return Arrays.asList(currencies).indexOf(currency);
    }

    private void addAmount(String currency, float amount){
        String finalBalance = Float.toString(Float.parseFloat(balances[currencyIndex(currency)]) + amount);
        balances[currencyIndex(currency)] = finalBalance;
    }

    private void subtractAmount(String currency, float amount){
        String finalBalance = Float.toString(Float.parseFloat(balances[currencyIndex(currency)]) - amount);
        balances[currencyIndex(currency)] = finalBalance;
    }

    public boolean isInDB(){
        return inDB;
    }
    //</editor-fold>

    private void initialiseCustomer(ReadFXCustomerInfoCSV readFXCustomerInfoCSV){
        String[] customerInfo = readFXCustomerInfoCSV.getCustomerInfo();
        for (int i = 0; i < MAX_CURRENCY_NUMBER; i++){
            currencies[i] = customerInfo[i+1];
            balances[i] = customerInfo[i+4];
        }
        maxCurrency = customerInfo[7];
        inDB = customerInfo[8].equals("In DB");
    }

    public Boolean checkBalance(String fromCurrency, String toCurrency, float amountToExchange) {

        // If customer is SGD, check if balance is sufficient for withdrawal
        if (fromCurrency.equals(BASE_CURRENCY)){
            float balance = databaseConnection.getBalanceFromAccount(customerID,"1");

            if (balance < amountToExchange){
                System.out.println("Insufficient Balance for conversion");
                System.out.println(String.format("Balance in SGD: %2f", balance));
                return false;
            }
        }

        // If customer has fromCurrency, check for sufficient balance to exchange
        else if (hasCurrency(fromCurrency)){
            if (getBalances(fromCurrency) < amountToExchange){
                System.out.println("Insufficient Balance for conversion");
                System.out.println(String.format("Balance in %s: %2f", fromCurrency, getBalances(fromCurrency)));
                // Print balance here
                return false;
            }
        }
        // If currency to exchange from not found, print error message
        else{
            System.out.println("Currency to exchange from not found!");
            System.out.printf("Current foreign currencies are: %s, %s, %s\n", getCurrencies(0), getCurrencies(1), getCurrencies(2));
            return false;
        }

        // If customer does not have toCurrency, check if max currency is reached
        if (toCurrency.equals(BASE_CURRENCY)){

        }
        else if (!hasCurrency(toCurrency)){
            // If customer has toCurrency, check for sufficient balance
            if (getMaxCurrency().equals("TRUE")){
                System.out.println("Max number of foreign currencies (3) reached");
                System.out.printf("Current foreign currencies are: %s, %s, %s\n", getCurrencies(0), getCurrencies(1), getCurrencies(2));
                return false;
            }
        }

        // If customerID is not in database, fromCurrency must be "SGD"
        if (!isInDB() && !fromCurrency.equals(BASE_CURRENCY)){
            System.out.println("If you are a new customer to foreign exchange, currency to convert from must be SGD");
            return false;
        }

        System.out.println("Good to go");
        return true;
    }

    public void updateBalances(String fromCurrency, String toCurrency, float amountToExchange, float amountExchanged, HashMap fullCustomerInfo, String filePath){

        if (fromCurrency.equals(toCurrency)){
            return;
        }

        if (fromCurrency.equals(BASE_CURRENCY)){
            // Call for the update balance from the customer side
            databaseConnection.withdrawAmount(customerID, "1",amountToExchange);
        }
        else {
            subtractAmount(fromCurrency, amountToExchange);
            if (getBalances(fromCurrency) == 0){
                setCurrencies(currencyIndex(fromCurrency), "");
            }
        }

        if (toCurrency.equals(BASE_CURRENCY)){
            // Call for the update balance from the customer side
            databaseConnection.depositAmount(customerID, "1",amountExchanged);
        }
        else if(hasCurrency(toCurrency)){
            addAmount(toCurrency, amountExchanged);
        }
        else {
            setCurrencies(currencyIndex(""),toCurrency);
            addAmount(toCurrency, amountExchanged);
        }

        // Updates maxCurrency value based on if empty currency slot exists
        updateMaxCurrency();

        WriteFXCustomerCSV writeFXCustomerCSV = new WriteFXCustomerCSV(fullCustomerInfo);
        writeFXCustomerCSV.writeToCustomerCSV(filePath, this);
    }

}

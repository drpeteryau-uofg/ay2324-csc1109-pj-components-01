package ForeignExchange;

import Authenticator.IQueryAuthenticator;
import CustomerDatabase.IQueryCustomerDatabase;

import java.util.HashMap;
import java.util.Scanner;

public class ForeignExchange
{

    private String customerID;
    private float amountToExchange;
    private float amountExchanged;
    private String fromCurrency;
    private String toCurrency;
    // private float fees;
    private HashMap<String, String[]> fullCustomerInfo = new HashMap<String, String[]>();
    final private String CUSTOMER_INFO_FILE_PATH = System.getProperty("user.dir") + "\\Data\\FXCustomerInfo.csv";
    final private String EXCHANGE_RATES_FILE_PATH = System.getProperty("user.dir") + "\\Data\\ExchangeRates.csv";
    private IQueryCustomerDatabase databaseConnection;

    // <editor-fold desc="Getter and Setters">
    /**
     * Class Constructor.
     *
     * @param queryCustomerDatabase Database connection to query customer information
     * @param queryAuthenticator    Authenticator to get the current customer id
     */
    public ForeignExchange(IQueryCustomerDatabase queryCustomerDatabase, IQueryAuthenticator queryAuthenticator)
    {
        this.fromCurrency = "SGD";
        this.toCurrency = "USD";

        this.databaseConnection = queryCustomerDatabase;
        customerID = queryAuthenticator.getAuthenticatedUserID();
    }

    /**
     * Gets the current customer ID
     *
     * @return Current customer ID
     */
    public String getCustomerID()
    {
        return customerID;
    }

    /**
     * Sets the current customer ID
     *
     * @param customerID Current customer ID
     */
    public void setCustomerID(String customerID)
    {
        // the current customer
        this.customerID = customerID;
    }

    /**
     * Sets currency to be exchanged from
     *
     * @param newCurrency Currency to be exchanged from
     */
    public void setFromCurrency(String newCurrency)
    {
        this.fromCurrency = newCurrency;
    }

    /**
     * Gets currency to be exchanged from
     * 
     * @return Currency to be exchanged from
     */
    public String getFromCurrency()
    {
        return this.fromCurrency;
    }

    /**
     * Sets the target currency
     * 
     * @param newCurrency Currency to be converted to
     */
    public void setToCurrency(String newCurrency)
    {
        this.toCurrency = newCurrency;
    }

    /**
     * Gets the target currency
     * 
     * @return Currency to be converted to
     */
    public String getToCurrency()
    {
        return this.toCurrency;
    }

    /**
     * Gets amount of money to be converted
     * 
     * @return Amount of money to be converted
     */
    public float getAmountToExchange()
    {
        return amountToExchange;
    }

    /**
     * Sets amount of money to be converted
     * 
     * @param amountToExchange Amount of money to be converted
     */
    public void setAmountToExchange(int amountToExchange)
    {
        this.amountToExchange = amountToExchange;
    }

    // </editor-fold>

    /**
     * Handles user input and currency exchange. Outputs data to let customer know about status of transaction.
     */
    public void convert()
    {
        getUserInput();
        displayExchangeInfo();
        System.out.println("Proceed? Y/N: ");
        Scanner myObj = new Scanner(System.in);
        String input = myObj.nextLine().toUpperCase();

        ReadFXCustomerInfoCSV readFXCustomerInfoCSV = new ReadFXCustomerInfoCSV(customerID, CUSTOMER_INFO_FILE_PATH);
        fullCustomerInfo = readFXCustomerInfoCSV.getFullCustomerInfo();
        FXCustomer customer = new FXCustomer(customerID, databaseConnection, readFXCustomerInfoCSV);

        Boolean checkEligible = customer.checkBalance(fromCurrency, toCurrency, amountToExchange);
        if (!checkEligible)
        {
            System.out.println("Transaction cancelled.");
            return;
        }

        boolean proceed = input.equals("Y") || input.equals("YES");
        if (proceed)
        {
            exchangeCurrencies();
            customer.updateBalances(fromCurrency, toCurrency, amountToExchange,
                    amountExchanged, fullCustomerInfo, CUSTOMER_INFO_FILE_PATH);
            System.out.println("Currency successfully exchanged!");
            displayBalance(customer);
        } else
        {
            System.out.println("Transaction cancelled.");
        }
    }

    /**
     * Exchanges the currency from one to another
     */
    private void exchangeCurrencies()
    {
        ReadExchangeRatesCSV rates = new ReadExchangeRatesCSV(EXCHANGE_RATES_FILE_PATH);
        // Create an error check for if currency is not found in the exchangeRates
        amountExchanged = amountToExchange / rates.getExchangeRatesForCurrency(fromCurrency)
                * rates.getExchangeRatesForCurrency(toCurrency);
    }

    /**
     * Retrieve user inputs for details of the currency exchange. From currency, to
     * currency and amount to be converted
     */
    public void getUserInput()
    {

        // Should display the balance of all currencies in the account
        Scanner myObj = new Scanner(System.in);
        System.out.print("Please enter your the currency you want to exchange from: ");
        this.fromCurrency = myObj.nextLine().toUpperCase();

        System.out.print("Please enter your the currency you want to exchange to: ");
        this.toCurrency = myObj.nextLine().toUpperCase();

        System.out.print("Please enter the amount you want to exchange: ");
        this.amountToExchange = myObj.nextFloat();
    }

    /**
     * Displays current transaction details to customer
     */
    public void displayExchangeInfo()
    {
        System.out.printf("Currency to exchange from: %s\n", this.fromCurrency);
        System.out.printf("Currency to exchange to: %s\n", this.toCurrency);
        System.out.printf("Amount to exchange: %.2f\n", this.amountToExchange);
    }

    /**
     * Displays the balance of the customer's account
     *
     * @param customer FXCustomer object containing the current customer information
     */
    public void displayBalance(FXCustomer customer)
    {
        // Include SGD balance later
        if (fromCurrency.equals("SGD"))
        {
            System.out.println(String.format("Balance in SGD: %2f", databaseConnection.getBalanceFromAccount(customerID, CUSTOMER_INFO_FILE_PATH)));
        }
        else {
            System.out.println(String.format("Balance in %s: %2f", fromCurrency, customer.getBalances(fromCurrency)));
        }

        if (toCurrency.equals("SGD"))
        {
            System.out.println(String.format("Balance in SGD: %2f", databaseConnection.getBalanceFromAccount(customerID, CUSTOMER_INFO_FILE_PATH)));
        }
        else{
            System.out.println(String.format("Balance in %s: %2f", toCurrency, customer.getBalances(toCurrency)));
        }
    }

    /**
     * Main method to run the program
     *
     * @param args
     */
    public static void main(String[] args)
    {
        class ExampleCustomerDatabase implements IQueryCustomerDatabase
        {
            float exampleCustomerBalance = 99999;

            /**
             * Gets all the account ID's for a customer
             *
             * @param customerID Customer ID to get the account IDs for
             * @return Array of account IDs
             */
            @Override
            public String[] getCustomerAccountIDs(String customerID)
            {
                System.out.println("Returned Account ID is '1' ");
                return new String[]{ "1" };
            }

            /**
             * Withdraws an amount from the customer's account
             *
             * @param customerID Customer ID to withdraw from
             * @param accountID Account ID to withdraw from
             * @param amount Amount to withdraw
             * @return True if withdrawal is successful, false if not
             */
            @Override
            public boolean withdrawAmount(String customerID, String accountID, float amount)
            {
                exampleCustomerBalance -= amount;
                // Else success
                // Other code that subtracts to the customer's account
                System.out.println("Withdrawal success");
                return true;
            }

            /**
             * Deposits an amount to the customer's account
             *
             * @param customerID Customer ID to deposit to
             * @param accountID Account ID to deposit to
             * @param amount Amount to deposit
             * @return True if deposit is successful
             */
            @Override
            public boolean depositAmount(String customerID, String accountID, float amount)
            {
                exampleCustomerBalance += amount;
                // Other code that adds to the customer's account
                System.out.println("Withdrawal success");
                return true;
            }

            /**
             * Gets the balance from the customer's account
             *
             * @param customerID Customer ID to get the balance from
             * @param accountID Account ID to get the balance from
             * @return Balance from the account
             */
            @Override
            public float getBalanceFromAccount(String customerID, String accountID)
            {
                // Example amount of money in account
                return exampleCustomerBalance;
            }

        }


        class ExampleAuthenticator implements IQueryAuthenticator
        {
            /**
             * Gets the authenticated user ID
             *
             * @return Authenticated user ID
             */
            @Override
            public String getAuthenticatedUserID()
            {
                // Example customer id
                return "1";
            }
        }

        ExampleCustomerDatabase database = new ExampleCustomerDatabase();
        ExampleAuthenticator authenticator = new ExampleAuthenticator();

        ForeignExchange fx = new ForeignExchange(database, authenticator);
        fx.convert();
    }

}

package ForeignExchange;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.HashMap;
import java.util.Scanner;

public class ReadExchangeRatesCSV {

    private HashMap<String, Float> exchangeRates = new HashMap<String, Float>();

    /**
     * Class Constructor.
     *
     * @param filepath File path of the ExchangeRates.csv file
     */
    public ReadExchangeRatesCSV(String filepath){
        readExchangeRates(filepath);
    }

    /**
     * Gets the HashMap of exchange rates
     * @return HashMap containing the exchange rates
     */
    public HashMap<String, Float> getExchangeRates(){
        return exchangeRates;
    }

    /**
     * Gets the exchange rate for a specific currency
     * @param currency Currency to get the exchange rate for
     * @return Exchange rate for the specified currency
     */
    public float getExchangeRatesForCurrency(String currency){
        return exchangeRates.get(currency);
    }

    /**
     * Reads the exchange rates from the CSV file
     * @param filepath File path of the ExchangeRates.csv file
     */
    private void readExchangeRates(String filepath){
        File file = new File(filepath);
        try {
            Scanner rowScanner = new Scanner(file);
            rowScanner.nextLine();
            while(rowScanner.hasNextLine()){
                String line = rowScanner.nextLine();
                String[] row = line.split(",");
                exchangeRates.put(row[0], Float.parseFloat(row[1]));
            }
            rowScanner.close();
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

}

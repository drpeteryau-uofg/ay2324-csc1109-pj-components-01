package ForeignExchange;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Scanner;

public class ReadFXCustomerInfoCSV {
    private String[] customerInfo = new String[9];
    private String customerID;
    private HashMap<String, String[]> fullCustomerInfo = new HashMap<String, String[]>();
    final private int IS_IN_DB_INDEX = 8;
    final private int CUSTOMER_ID_INDEX = 0;

    /**
     * Class Constructor.
     *
     * @param customerID Current Customer ID to be read from the CSV file
     * @param filePath File path of the CustomerInfo.csv file
     */
    public ReadFXCustomerInfoCSV(String customerID, String filePath){
        this.customerID = customerID;
        readFXCustomerInfoCSV(filePath);
    }

    /**
     * Sets the customer ID
     * @param customerID
     */
    public void setCustomerID(String customerID){
        this.customerID = customerID;
    }

    /**
     * Gets the customer information in an array
     * @return String array containing the customer information
     */
    public String[] getCustomerInfo(){
        return customerInfo;
    }

    /**
     * Gets the full customer information in a HashMap
     * @return HashMap containing the full customer data from customer info CSV
     */
    public HashMap<String, String[]> getFullCustomerInfo(){
        return fullCustomerInfo;
    }

    /**
     * Reads the customer information from the CSV file
     * @param filePath File path of the CustomerInfo.csv file
     */
    private void readFXCustomerInfoCSV(String filePath){
        File file = new File(filePath);
        try {
            Scanner rowScanner = new Scanner(file);
            rowScanner.nextLine();
            while(rowScanner.hasNextLine()){
                String line = rowScanner.nextLine();
                String[] row = line.split(",");
                fullCustomerInfo.put(row[CUSTOMER_ID_INDEX],Arrays.copyOfRange(row, 1, row.length));
                if (row[CUSTOMER_ID_INDEX].equals(customerID)){
                    System.arraycopy(row, 0, customerInfo, 0, row.length);
                    customerInfo[IS_IN_DB_INDEX] = "In DB";
                }
            }
            // Create new customer entry if not found.
            if (customerInfo[CUSTOMER_ID_INDEX] == null){
                customerInfo = new String[]{customerID, "", "", "", "0", "0", "0", "FALSE", "Not in DB"};
            }
        } catch (FileNotFoundException e) {
            throw new RuntimeException(e);
        }
    }
}

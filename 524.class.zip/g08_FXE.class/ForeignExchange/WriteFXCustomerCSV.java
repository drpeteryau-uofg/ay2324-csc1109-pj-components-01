package ForeignExchange;

import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.util.HashMap;

public class WriteFXCustomerCSV {
    private HashMap<String, String[]> fullCustomerInfo;

    /**
     * Class Constructor.
     *
     * @param fullCustomerInfo HashMap containing all customer information in CustomerInfo.csv
     */
    public WriteFXCustomerCSV(HashMap<String, String[]> fullCustomerInfo){
        this.fullCustomerInfo = fullCustomerInfo;
    }

    /**
     * Writes the updated customer information to the CustomerInfo.csv file.
     *
     * @param filePath File path of the CustomerInfo.csv file
     * @param customer FXCustomer object containing the current customer information
     */
    public void writeToCustomerCSV(String filePath, FXCustomer customer){
        // write will read the file, then copy each line.
        // When it finds customer ID, use the new customer class's data.
        // Continue copying till the end
        // If didn't meet customer data till the end, add the new customer data at the end
        String header = "CustomerID, Currency1, Currency2, Currency3, Balance1, Balance2, Balance3, MaxCurrency";
        String[] customerInfo = {customer.getCustomerID(),
                                String.join(",", customer.getCurrenciesArray()),
                                String.join(",", customer.getBalancesArray()),
                                                            customer.getMaxCurrency()};

        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filePath))) {
            writer.write(header);
            writer.newLine();
            for (String key : fullCustomerInfo.keySet()) {
                if (key.equals(customer.getCustomerID())){
                    writer.write(String.join(",", customerInfo));
                    writer.newLine();
                }
                else{
                    writer.write(key + "," + String.join(",", fullCustomerInfo.get(key)));
                    writer.newLine();
                }
            }
            if (!customer.isInDB()){
                writer.write(String.join(",", customerInfo));
                writer.newLine();
            }
            System.out.println("Account balance updated successfully.");
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}

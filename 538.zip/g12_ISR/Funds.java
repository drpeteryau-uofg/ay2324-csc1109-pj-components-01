import java.util.*;
import java.io.*;

/**
 * Represents a fund with a name and unit price.
 */
public class Funds {
    private String fundName;
    private double unitPrice;

    /**
     * Constructs a new Funds object with the specified fund name.
     *
     * @param fundName The name of the fund.
     */
    public Funds(String fundName) {
        this.fundName = fundName;
        unitPrice = new Random().nextDouble(100 - 10 + 1) + 10;// Generate a random unit price amount amount between 10 and 10 (inclusive)
    }

    /**
     * Gets the name of the fund.
     *
     * @return The name of the fund.
     */
    public String getFundName() {
        return this.fundName;
    }

    /**
     * Gets the unit price of the fund.
     *
     * @return The unit price of the fund.
     */
    public double getUnitPrice() {
        return this.unitPrice;
    }

    /**
     * Retrieves a fund by its name from the list of funds.
     *
     * @param funds    The list of funds.
     * @param fundName The name of the fund to retrieve.
     * @return The fund with the specified name, or null if not found.
     */
    public static Funds getFundsByFundName(List<Funds> funds, String fundName) {
        return funds.stream().filter(fund -> fund.getFundName().equals(fundName)).findFirst().orElse(null);
    }

    /**
     * Loads fund data from a CSV file.
     *
     * @param filePath The path to the CSV file containing fund data.
     * @return A list of Funds objects loaded from the CSV file.
     */
    public static List<Funds> loadFundDataFromCSV(String filePath) {
        List<Funds> fundsList = new ArrayList<>();
        try (Scanner csvScanner = new Scanner(new File(filePath))) {
            if (csvScanner.hasNextLine()) {
                csvScanner.nextLine();
            }
            while (csvScanner.hasNextLine()) {
                String[] tokens = csvScanner.nextLine().split(",");
                fundsList.add(new Funds(tokens[0]));
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return fundsList;
    }

    /**
     * Updates fund data in a CSV file.
     *
     * @param filePath The path to the CSV file containing fund data.
     * @param fundName The name of the fund to update.
     * @param fundUnit The unit price of the fund.
     */
    public static void updateFundsToCSV(String filePath, String fundName, double fundUnit) {
        File oldFile = new File(filePath);
        File newFile = new File("tempFunds.csv");
        try {
            PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter("tempFunds.csv", true)));
            Scanner writer = new Scanner(oldFile);
            while (writer.hasNextLine()) {
                String[] tokens = writer.nextLine().split(",");

                if (tokens[0].equals(fundName)) {
                    pw.println(fundName + "," + fundUnit);
                } else {
                    pw.println(tokens[0] + "," + tokens[1]);
                }
            }
            writer.close();
            pw.flush();
            pw.close();
            // Replace the old file with the updated one
            if (!oldFile.delete()) {
                System.out.println("Could not delete the old file");
                return;
            }
            if (!newFile.renameTo(oldFile)) {
                System.out.println("Could not rename the new file");
            }
        } catch (Exception e) {
            System.out.println("Error!");
        }
    }
}
import java.time.temporal.ChronoUnit;
import java.time.format.*;
import java.time.*;
import java.util.*;
import java.io.*;

/**
 * The Insurance class gives basic Insurance policy information like the policy name, status, type, inception date, maturity date, owner, sum assured, premium amount, premium frequency, total premium paid, total withdrawal amount, fund name A, fund allocation A, fund units A, fund name B, fund allocation B, fund units B
*/
public class Insurance {
    private String Username, policyName, policyStatus, policyType, policyOwner, premiumFrequency, fundNameA, fundNameB;
    private int policyNumber;
    private LocalDate inception_date, maturity_date;
    private double sumAssured, premiumAmount, totalPremiumPaid, totalWithdrawalAmount, fundAllocationA, fundUnitA, fundAllocationB, fundUnitB;
    private boolean transactionAllowed;
    static DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("dd-MM-yyyy");

    /**
     * Constructs an Insurance object with the specified details.
     *
     * @param Username            The username of the policy holder.
     * @param policyNumber        The policy number.
     * @param policyName          The name of the insurance policy.
     * @param policyStatus        The status of the insurance policy.
     * @param policyType          The type of insurance policy.
     * @param inception_date      The date when the insurance policy starts.
     * @param maturity_date       The date when the insurance policy matures.
     * @param policyOwner         The owner of the insurance policy.
     * @param sumAssured          The sum assured by the insurance policy.
     * @param premiumAmount       The premium amount of the insurance policy.
     * @param premiumFrequency    The frequency of premium payment.
     * @param totalPremiumPaid    The total premium paid for the insurance policy.
     * @param totalWithdrawalAmount The total amount withdrawn from the insurance policy.
     * @param fundNameA           The name of Fund A associated with the policy.
     * @param fundAllocationA     The allocation percentage for Fund A.
     * @param fundUnitA           The unit of Fund A associated with the policy.
     * @param fundNameB           The name of Fund B associated with the policy.
     * @param fundAllocationB     The allocation percentage for Fund B.
     * @param fundUnitB           The unit of Fund B associated with the policy.
     * @param transactionAllowed  Indicates if transactions are allowed for the policy.
    */
    public Insurance(String Username, int policyNumber, String policyName, String policyStatus, String policyType, LocalDate inception_date, LocalDate maturity_date, String policyOwner, double sumAssured, double premiumAmount, String premiumFrequency, double totalPremiumPaid, double totalWithdrawalAmount, String fundNameA, double fundAllocationA, double fundUnitA, String fundNameB, double fundAllocationB, double fundUnitB, boolean transactionAllowed) {
        this.Username = Username;
        this.policyNumber = policyNumber;
        this.policyName = policyName;
        this.policyStatus = "Inforce";
        this.policyType = policyType;
        this.inception_date = inception_date;
        this.maturity_date = maturity_date;
        this.policyOwner = policyOwner;
        this.sumAssured = sumAssured;
        this.premiumAmount = premiumAmount;
        this.premiumFrequency = premiumFrequency;
        this.totalPremiumPaid = totalPremiumPaid;
        this.totalWithdrawalAmount = totalWithdrawalAmount;
        this.fundNameA = fundNameA;
        this.fundAllocationA = fundAllocationA;
        this.fundUnitA = fundUnitA;
        this.fundNameB = fundNameB;
        this.fundAllocationB = fundAllocationB;
        this.fundUnitB = fundUnitB;
        this.transactionAllowed = transactionAllowed;
    }
    
    /**
     * Retrieves the username associated with this object.
     *
     * @return The username.
    */
    public String getUsername() {
        return this.Username;
    }

    /**
     * Gets the policy number.
     *
     * @return The policy number.
    */
    public int getPolicyNumber() {
        return this.policyNumber;
    }

    /**
     * Retrieves the name of the policy.
     *
     * @return The name of the policy.
    */
    public String getPolicyName() {
        return this.policyName;
    }

    /**
     * Retrieves the policy status of this insurance policy.
     *
     * @return The policy status.
    */
    public String getPolicyStatus() {
        return this.policyStatus;
    }

    /**
     * Retrieves the type of the policy.
     *
     * @return The type of the policy.
    */
    public String getPolicyType() {
        return this.policyType;
    }

    /**
     * Gets the inception date of the insurance policy.
     *
     * @return The inception date of the insurance policy.
    */
    public LocalDate getInception_date() {
        return this.inception_date;
    }

    /**
     * Retrieves the maturity date of the insurance policy.
     *
     * @return The maturity date of the insurance policy.
    */
    public LocalDate getMaturity_date() {
        return this.maturity_date;
    }

    /**
     * Retrieves the policy owner.
     *
     * @return The policy owner.
    */
    public String getPolicyOwner() {
        return this.policyOwner;
    }

    /**
     * Retrieves the sum assured for this insurance policy.
     *
     * @return The sum assured.
    */
    public double getSumAssured() {
        return this.sumAssured;
    }

    /**
     * Retrieves the premium amount of the insurance policy.
     *
     * @return The premium amount.
    */
    public double getPremiumAmount() {
        return this.premiumAmount;
    }

    /**
     * Retrieves the premium frequency of the insurance policy.
     *
     * @return The premium frequency of the insurance policy.
    */
    public String getPremiumFrequency() {
        return this.premiumFrequency;
    }

    /**
     * Retrieves the total premium paid for this insurance policy.
     *
     * @return The total premium paid.
    */
    public double getTotalPremiumPaid() {
        return this.totalPremiumPaid;
    }

    /**
     * Retrieves the total withdrawal amount associated with this account.
     *
     * @return The total withdrawal amount.
    */
    public double getTotalWithdrawalAmount() {
        return this.totalWithdrawalAmount;
    }

    /**
     * Retrieves the name of Fund A.
     *
     * @return The name of Fund A.
    */
    public String getFundNameA() {
        return this.fundNameA;
    }

    /**
     * Retrieves the allocation percentage of Fund A.
     *
     * @return The allocation percentage of Fund A.
    */
    public double getFundAllocationA() {
        return this.fundAllocationA;
    }

    /**
     * Retrieves the number of units of Fund A.
     *
     * @return The number of units of Fund A.
    */
    public double getFundUnitA() {
        return this.fundUnitA;
    }

    /**
     * Gets the name of Fund B.
     *
     * @return The name of Fund B.
    */
    public String getFundNameB() {
        return this.fundNameB;
    }

    /**
     * Retrieves the allocation percentage for Fund B.
     *
     * @return The allocation percentage for Fund B.
    */
    public double getFundAllocationB() {
        return this.fundAllocationB;
    }

    /**
     * Retrieves the number of units for Fund B in this insurance policy.
     *
     * @return The number of units for Fund B.
    */
    public double getFundUnitB() {
        return this.fundUnitB;
    }

    /**
     * Gets the transaction allowed status.
     *
     * @return True if transactions are allowed, false otherwise.
    */
    public boolean getTransactionAllowed() {
        return this.transactionAllowed;
    }

    /**
     * Retrieves an insurance policy by the username of the policy owner.
     *
     * @param insurances The list of insurance policies to search.
     * @param Username   The username of the policy owner.
     * @return The insurance policy owned by the specified username, or null if not found.
     */
    public static Insurance getInsuranceByUsername(List<Insurance> insurances, String Username) {
        return insurances.stream().filter(insurance -> insurance.getUsername().equals(Username)).findFirst().orElse(null);
    }

    /**
     * Retrieves the insurance policy with the specified policy number.
     *
     * @param insurances   The list of all insurance policies.
     * @param policyNumber The policy number of the insurance policy to retrieve.
     * @return The insurance policy with the specified policy number, or null if not found.
    */
    public static Insurance getInsuranceByPolicyNumber(List<Insurance> insurances, int policyNumber) {
        return insurances.stream().filter(insurance -> insurance.getPolicyNumber() == policyNumber).findFirst().orElse(null);
    }

    /**
     * Retrieves all insurance policies associated with the specified user.
     *
     * @param insurances The list of all insurance policies.
     * @param user       The user whose insurance policies are to be retrieved.
     * @return The list of insurance policies associated with the specified user.
    */
    public static List<Insurance> getInsuranceAccount(List<Insurance> insurances, User user) {
        return insurances.stream().filter(insurance -> insurance.getUsername().equals(user.getUsername())).toList();
    }

    /**
     * Retrieves all insurance policies with transaction allowed for the specified user.
     *
     * @param insurances The list of all insurance policies.
     * @param user       The user whose insurance policies are to be retrieved.
     * @return The list of insurance policies with transaction allowed for the specified user.
    */
    public static List<Insurance> getInsuranceAccountByStatus(List<Insurance> insurances, User user) {
        return insurances.stream().filter(insurance -> insurance.getUsername().equals(user.getUsername()) && insurance.getTransactionAllowed()).toList();
    }

    /**
     * Displays information about the insurance policy.
     * Includes details such as policy number, name, type, inception date, maturity date, owner,
     * sum assured, premium amount, premium frequency, total premium paid, and total withdrawn amount.
     * If the policy type is an Investment-Linked Insurance Plan, it also displays information about the funds.
     */
    public void displayInsuranceInfo() {
        System.out.println("\nPolicy Number: " + getPolicyNumber() + "\nPolicy Name: " + policyName + "\nPolicy Type: " + policyType + "\nPolicy Status: " + policyStatus + "\nPolicy Inception Date: " + inception_date.format(dateFormatter) + "\nPolicy Maturity Date: " + maturity_date.format(dateFormatter) + "\nPolicy Owner: " + policyOwner);
        System.out.printf("Sum Assured: $%.2f%nPremium Amount: $%.2f%n", sumAssured, premiumAmount);
        System.out.println("Premium Frequency: " + premiumFrequency);
        System.out.printf("Total Premium Paid: $%.2f%nTotal Withdrawn Amount: $%.2f%n", totalPremiumPaid, totalWithdrawalAmount);
        if (policyType.equals("Investment-Linked Insurance Plan")) {
            System.out.println("Policy Funds Information:");
            displayFundInformation(fundNameA, fundAllocationA, fundUnitA);
            displayFundInformation(fundNameB, fundAllocationB, fundUnitB);
        }
    }

    /**
     * Displays information about a fund.
     *
     * @param fundName      The name of the fund.
     * @param fundAllocation The percentage of premium allocation for the fund.
     * @param fundUnit      The number of fund units.
    */
    public void displayFundInformation(String fundName, double fundAllocation, double fundUnit) {
        System.out.println(fundName + ":");
        System.out.printf("    Premium Allocation: %.2f%%%n    Fund Units: %.2f%n", fundAllocation, fundUnit);
    }

    /**
     * Adds an insurance account for the specified user based on the chosen policy.
     *
     * @param scanner     The Scanner object to read user input.
     * @param currentUser The User object representing the current user.
    */
    public static void addInsuranceAccount(Scanner scanner, User currentUser) {
        List<Funds> fundsList = Funds.loadFundDataFromCSV("funds.csv"); // Load fund data from CSV file
        try {
            String Username = currentUser.getUsername();
            int policyNumber = new Random().nextInt(10000000) + 10000000; // Generate a random 8 digit policy number starting with 1

            System.out.println("Welcome to Insurance System! The following insurance plans are offered to cater to your needs! \n1. AdventureShield \nTravel Insurance with sum assured of $50,000 at the cost of $79.90. \n2. HealthCare Plus \nHealth Insurance with sum assured of $200,000. The annual premium is $250. \n3. StabilityAssure \nTraditional Insurance Plan with sum assured of $350,000. The monthly premium is $250. \n4. WealthBuilder Advantage \nInvestment-Linked Insurance Plan with sum assured of $350,000. The monthly premium is $250, and it offers investment options through two funds: Fund A and Fund B.");
            System.out.println("Enter your policy choice:");
            int policyChoice = Integer.parseInt(scanner.next());
            
            String policyName = "", policyType = "", premiumFrequency = "", policyStatus = "Inforce", fundNameA = "Fund A", fundNameB = "Fund B";
            double sumAssured = 350000, premiumAmount = 250, totalPremiumPaid = 250, fundAllocationA = 0, fundAllocationB = 0, fundUnitA = 0, fundUnitB = 0;
            LocalDate inception_date = LocalDate.parse(LocalDate.now().format(dateFormatter), dateFormatter);
            LocalDate maturity_date = LocalDate.parse(LocalDate.now().format(dateFormatter), dateFormatter);

            switch (policyChoice) {
                case 1: // Travel Insurance
                    policyName = "Adventure Shield";
                    policyType = "Travel Insurance";
                    sumAssured = 50000.0;
                    inception_date = maturity_date = null;
                    boolean validDate = false;
                    // Loop until a valid date is entered 
                    while (!validDate || inception_date.isAfter(maturity_date)) {
                        try {
                            System.out.println("Enter the coverage start date [dd-MM-yyyy]:");
                            inception_date = LocalDate.parse(scanner.next(), dateFormatter);
                            System.out.println("Enter the coverage end date [dd-MM-yyyy]:");
                            maturity_date = LocalDate.parse(scanner.next(), dateFormatter);

                            if (inception_date.isAfter(LocalDate.now()) && maturity_date.isAfter(inception_date)) {
                                validDate = true; // Exit the loop if both dates are valid
                            } else {
                                System.out.println("Please enter valid future dates with end date after start date.");
                            }
                        } catch (DateTimeParseException e) {
                            System.out.println("Invalid date format. Please enter dates in the format dd-MM-yyyy.");
                        }
                    }
                    premiumAmount = totalPremiumPaid = 79.9;
                    premiumFrequency = "One-Time Payment";
                    break;
                case 2: // Health Insurance
                    policyName = "HealthCare Plus";
                    policyType = "Health Insurance";
                    maturity_date = maturity_date.plusYears(3);
                    premiumFrequency = "Annually";
                    break;
                case 3: // Traditional Insurance Plan
                    policyName = "Stability Assure";
                    policyType = "Traditional Insurance Plan";
                    maturity_date = maturity_date.plusYears(4);
                    premiumFrequency = "Monthly";
                    break;
                case 4: // Investment-Linked Insurance Plan
                    policyName = "WealthBuilder Advantage";
                    policyType = "Investment-Linked Insurance Plan";
                    maturity_date = maturity_date.plusYears(4);
                    premiumFrequency = "Monthly";
                    boolean validAllocation = false;
                    // Loop until valid premium allocation is entered
                    while (!validAllocation) {
                        try {
                            // Prompt user to enter their preferred premium allocation between Fund A and Fund B, which is only available for Investment-Linked Insurance Plan
                            System.out.println("The percentage of premium allocation for funds, Fund A and Fund B, should add up to 100%. Please assign a percentage for each fund.");
                            System.out.println("Enter the percentage of premium allocation for Fund A [e.g. 35]: ");
                            fundAllocationA = Double.parseDouble(scanner.next());
                            System.out.println("Enter the percentage of premium allocation for Fund B: [e.g. 65]");
                            fundAllocationB = Double.parseDouble(scanner.next());

                            // Check if user entered a valid allocation that sums up to 100%
                            if (fundAllocationA + fundAllocationB == 100.00) {
                                validAllocation = true;
                                // Retrieve unit price for Fund A and Fund B 
                                Funds fundA = Funds.getFundsByFundName(fundsList, "Fund A");
                                Funds fundB = Funds.getFundsByFundName(fundsList, "Fund B");
                                Funds.updateFundsToCSV("funds.csv", fundA.getFundName(), fundA.getUnitPrice());
                                Funds.updateFundsToCSV("funds.csv", fundB.getFundName(), fundB.getUnitPrice());
                                // Calculate the fund units purchased
                                fundUnitA = (((premiumAmount / 100) * fundAllocationA) / fundA.getUnitPrice());
                                fundUnitB = (((premiumAmount / 100) * fundAllocationB) / fundB.getUnitPrice());
                            } else {
                                System.out.println("The total percentage allocation does not add up to 100%. Please enter valid entries.");
                            }
                        } catch (Exception e) {
                            e.getMessage();
                        }
                    }
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
                    break;
            }

            // Withdraw premium payment for policy inception. Policy inception will only proceed if payment is successful.
            if (Transaction.deposit_Withdraw("Policy inception payment", scanner, Account.getUserAccount(Account.loadAccountDataFromCSV("accounts.csv"), currentUser), premiumAmount)) {
                // Write insurance data and insurance transaction data to their respective CSV files
                writeInsuranceString("insurances.csv", new Insurance(Username, policyNumber, policyName, policyStatus, policyType, inception_date, maturity_date, Username, sumAssured, premiumAmount, premiumFrequency, totalPremiumPaid, 0, fundNameA, fundAllocationA, fundUnitA, fundNameB, fundAllocationB, fundUnitB, true));
                TransactionsInsurance.writeTransaction("insuranceTransactions.csv", new TransactionsInsurance(policyNumber, "Purchase of Insurance Policy Plan", LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss")), premiumAmount));
            } else {
                System.out.println("Error: Premium payment failed due to insufficient funds. Thus, purchase of insurance policy plan is not successful.");
            }
        } catch (Exception e) {
            e.getMessage();
        }
    }

    /**
     * Generates menu options for insurance-related actions, such as purchasing new insurance, displaying policy information,
     * making premium payments, surrendering policies, and viewing transaction history.
     *
     * @param scanner     The Scanner object for user input.
     * @param currentUser The current user for whom the insurance menu options are generated.
    */
    public static void generateInsuranceMenuOptions(Scanner scanner, User currentUser) {
        List<Insurance> allInsurance = loadInsuranceDataFromCSV("insurances.csv"); // Load all insuracne data from CSV file
        List<Insurance> insuranceAccounts = Insurance.getInsuranceAccount(allInsurance, currentUser); // Get insurance accounts for the current user
        int insuranceChoice, selectedPolicyNumber;
        do {
            System.out.println("\nChoose an Insurance action: \n1. Purchase New Insurance Plan \n2. Display Insurance Policy Information \n3. Premium Payment \n4. Policy Surrender \n5. Transaction History \n0. Exit");
            System.out.println("Enter your choice: ");
            insuranceChoice = Integer.parseInt(scanner.next());
            Security security = new Security(); 

            switch (insuranceChoice) {
                case 1: // 1. Purchase New Insurance Plan
                    // Perform 2FA Authentication
                    security.setUserEmail(currentUser.getEmail());
                    String sentCodeForCase1 = security.performTwoFactorAuthentication(); // This method now returns the sent 2FA code
                    if (sentCodeForCase1 == null || sentCodeForCase1.isEmpty()) {
                        System.out.println("Failed to send 2FA code. Exiting.");
                        System.exit(0);
                    }
                    scanner.nextLine();
                    boolean is2FASuccessfulForCase1 = false;
                    for (int attempts = 0; attempts < 3; attempts++) {
                        String enteredCode = scanner.nextLine().trim();
                        if (security.verifyTwoFactorAuthentication(enteredCode)) {
                            System.out.println("2FA verification successful.");
                            is2FASuccessfulForCase1 = true;
                            break; // Break the loop if verification is successful
                        } else {
                            if (attempts < 2) { // Avoid printing on the last attempt
                                System.out.println("Invalid 2FA code. Attempts left: " + (2 - attempts));
                            }
                        }
                    }

                    if (!is2FASuccessfulForCase1) {
                        System.out.println("Too many failed 2FA attempts. Exiting.");
                        System.exit(0);
                    } else {
                        addInsuranceAccount(scanner, currentUser);
                    }
                    break;
                case 2: // 2. Display Insurance Policy Information
                case 3: // 3. Premium Payment
                case 4: // 4. Policy Surrender
                case 5: // 5. Transaction History
                    // Perform 2FA Authentication
                    security.setUserEmail(currentUser.getEmail());
                    String sentCodeForCase5 = security.performTwoFactorAuthentication(); // This method now returns the sent 2FA code
                    if (sentCodeForCase5 == null || sentCodeForCase5.isEmpty()) {
                        System.out.println("Failed to send 2FA code. Exiting.");
                        System.exit(0);
                    }
                    scanner.nextLine();
                    boolean is2FASuccessfulForCase5 = false;
                    for (int attempts = 0; attempts < 3; attempts++) {
                        String enteredCode = scanner.nextLine().trim();
                        if (security.verifyTwoFactorAuthentication(enteredCode)) {
                            System.out.println("2FA verification successful.");
                            is2FASuccessfulForCase5 = true;
                            break; // Break the loop if verification is successful
                        } else {
                            if (attempts < 2) { // Avoid printing on the last attempt
                                System.out.println("Invalid 2FA code. Attempts left: " + (2 - attempts));
                            }
                        }
                    }

                    if (!is2FASuccessfulForCase5) {
                        System.out.println("Too many failed 2FA attempts. Exiting.");
                        System.exit(0);
                    } else {
                        // Determine insurance accounts available for the transactions based on the user's choice
                        insuranceAccounts = (insuranceChoice == 2 || insuranceChoice == 5) ? getInsuranceAccount(allInsurance, currentUser):getInsuranceAccountByStatus(allInsurance, currentUser);
                        selectedPolicyNumber = displayNValidatePolicyNumbers(scanner,insuranceAccounts); // Display policy numbers and validate user's choice
                        if (selectedPolicyNumber != -1) { // Perform action based on user's choice
                            if(insuranceChoice == 2){
                                getInsuranceByPolicyNumber(allInsurance, selectedPolicyNumber).displayInsuranceInfo();
                            } else if (insuranceChoice == 3){
                                getInsuranceByPolicyNumber(allInsurance, selectedPolicyNumber).premiumPayment(scanner, currentUser);
                            } else if (insuranceChoice == 4){
                                getInsuranceByPolicyNumber(allInsurance, selectedPolicyNumber).policySurrender(scanner, currentUser);
                            } else if (insuranceChoice == 5){
                                System.out.println("*****************************");
                                System.out.println("Last 10 Insurance Transactions:");
                                System.out.println("*****************************");
                                List<TransactionsInsurance> insuranceTrans = TransactionsInsurance.getUserInsuranceTransactions(TransactionsInsurance.loadInsuranceTransactionDataFromCSV("insuranceTransactions.csv"), getInsuranceByPolicyNumber(allInsurance, selectedPolicyNumber));

                                for (int i = 1; i <= Math.min(insuranceTrans.size(), 10); i++) {
                                    TransactionsInsurance transactionInsurance = insuranceTrans.get(insuranceTrans.size() - i);
                                    System.out.println("Transaction " + i + ":");
                                    System.out.println("Transaction Type: " + transactionInsurance.getTransactionType());
                                    System.out.printf("Amount: $%.2f%n", transactionInsurance.getTransactionAmount());
                                    System.out.println("Time Stamp: " + transactionInsurance.getLogTime() + "\n");
                                }
                                System.out.println("*****************************");
                            }
                        } else {
                            System.out.println("Invalid choice. Please enter a number between 1 and " + insuranceAccounts.size() + ".");
                        }
                    }
                    break;
                case 0:
                    System.out.println("Exiting Insurance Menu of SIT.");
                    break;
                default:
                    System.out.println("Invalid choice. Please enter a valid option.");
                    break;
            }
            allInsurance = loadInsuranceDataFromCSV("insurances.csv"); // Reload all insurance data from CSV file
        } while (insuranceChoice != 0);
    }

    /**
     * Loads insurance data from a CSV file.
     *
     * @param filePath The path to the CSV file containing insurance data.
     * @return A list of insurance objects loaded from the CSV file.
    */
    public static List<Insurance> loadInsuranceDataFromCSV(String filePath) {
        List<Insurance> insuranceList = new ArrayList<>();
        try (Scanner csvScanner = new Scanner(new File(filePath))) {
            if (csvScanner.hasNextLine()) {
                csvScanner.nextLine();
            }
            while (csvScanner.hasNextLine()) {
                String[] tokens = csvScanner.nextLine().split(",");
                insuranceList.add(new Insurance(tokens[0], Integer.parseInt(tokens[1]), tokens[2], tokens[3], tokens[4], LocalDate.parse(tokens[5], dateFormatter), LocalDate.parse(tokens[6], dateFormatter), tokens[7], Double.parseDouble(tokens[8]), Double.parseDouble(tokens[9]), tokens[10], Double.parseDouble(tokens[11]), Double.parseDouble(tokens[12]), tokens[13], Double.parseDouble(tokens[14]), Double.parseDouble(tokens[15]), tokens[16], Double.parseDouble(tokens[17]), Double.parseDouble(tokens[18]), Boolean.parseBoolean(tokens[19])));
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return insuranceList;
    }

    /**
     * Writes an insurance policy to a CSV file.
     *
     * @param filePath The file path of the CSV file.
     * @param i        The insurance policy to be written.
    */
    public static void writeInsuranceString(String filePath, Insurance i) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath, true))) {
            StringBuilder sb = new StringBuilder();
            sb.append("\n" + i.getUsername() + "," + i.getPolicyNumber() + "," + i.getPolicyName() + "," + i.getPolicyStatus() + "," + i.getPolicyType() + "," + i.getInception_date().format(dateFormatter) + "," + i.getMaturity_date().format(dateFormatter) + "," + i.getPolicyOwner() + "," + i.getSumAssured() + "," + i.getPremiumAmount() + "," + i.getPremiumFrequency() + "," + i.getTotalPremiumPaid() + "," + i.getTotalWithdrawalAmount() + "," + i.getFundNameA() + "," + i.getFundAllocationA() + "," + i.getFundUnitA() + "," + i.getFundNameB() + "," + i.getFundAllocationB() + "," + i.getFundUnitB() + "," + i.getTransactionAllowed());
            bw.write(sb.toString());
            
            System.out.println("The insurance plan is purchased successfully.");
        } catch (Exception e) {
            System.out.println("Error: Please try again!");
        }
    }

    /**
     * Updates the insurance data in the CSV file with the provided information.
     *
     * @param filePath              The file path of the CSV file.
     * @param policyNumber          The policy number to identify the insurance policy to update.
     * @param policyStatus          The new status of the insurance policy.
     * @param transactionAllowed    The flag indicating whether transactions are allowed for the policy.
     * @param totalWithdrawalAmount The new total withdrawal amount for the policy.
     * @param newTotalPremiumPaid   The new total premium paid for the policy.
     * @param fundUnitA             The updated number of units for Fund A.
     * @param fundUnitB             The updated number of units for Fund B.
    */
    public static void updateInsuranceDataToCSV(String filePath, int policyNumber, String policyStatus, boolean transactionAllowed, double totalWithdrawalAmount, double newTotalPremiumPaid, double fundUnitA, double fundUnitB) {
        File oldFile = new File(filePath);
        File newFile = new File("tempInsurance.csv");
        try {
            PrintWriter pw = new PrintWriter(new BufferedWriter(new FileWriter("tempInsurance.csv", true)));
            Scanner writer = new Scanner(oldFile);
            while (writer.hasNextLine()) {
                String line = writer.nextLine();
                String[] tokens = line.split(",");
                if (tokens[1].equals(String.valueOf(policyNumber))) {
                    pw.print(tokens[0] + "," + policyNumber + "," + tokens[2] + "," + policyStatus + "," + tokens[4] + "," + tokens[5] + "," + tokens[6] + "," + tokens[7] + "," + tokens[8] + "," + tokens[9] + "," + tokens[10] + "," + newTotalPremiumPaid + "," + totalWithdrawalAmount + "," + tokens[13] + "," + tokens[14] + "," + fundUnitA + "," + tokens[16] + "," + tokens[17] + "," + fundUnitB + "," + transactionAllowed);
                } else {
                    pw.print(line);
                }
                if (writer.hasNextLine()) {
                    pw.println(); // Add newline only if there's another line
                }
            }
            writer.close();
            pw.flush();
            pw.close();
            // Replace the old file with the updated one
            if (!oldFile.delete()) {
                System.out.println("Could not delete the old file");
                return;
            }
            if (!newFile.renameTo(oldFile)) {
                System.out.println("Could not rename the new file");
            }
        } catch (Exception e) {
            System.out.println("Error!");
        }
    }

    /**
     * Displays and validates policy numbers based on user input.
     *
     * @param scanner          The Scanner object used for user input.
     * @param insuranceAccounts The list of insurance accounts containing policy numbers.
     * @return The selected policy number if valid, otherwise returns -1.
    */
    public static int displayNValidatePolicyNumbers(Scanner scanner,List<Insurance> insuranceAccounts) {
        System.out.println("Please select policy for the transaction:"); 
        // Display the list of available insurance policies
        for (int i = 0; i < insuranceAccounts.size(); i++) {
            System.out.println((i + 1) + ". " + insuranceAccounts.get(i).getPolicyNumber());
        }
        int selectedPolicyNumber = scanner.nextInt();
        // Validate the selected policy number and return it if valid, otherwise return -1
        return (selectedPolicyNumber >= 1 && selectedPolicyNumber <= insuranceAccounts.size()) ? insuranceAccounts.get(selectedPolicyNumber - 1).getPolicyNumber() : -1;
    }

    /**
     * Performs premium payment for the insurance policy.
     *
     * @param scanner     Scanner object to read user input.
     * @param currentUser The current user for whom the premium payment is being made.
     */
    public void premiumPayment(Scanner scanner, User currentUser) {
        List<Funds> fundsList = Funds.loadFundDataFromCSV("funds.csv"); // Load fund data from CSV file
        List<Account> userAccounts = Account.getUserAccount(Account.loadAccountDataFromCSV("accounts.csv"), currentUser); // Load user accounts from CSV file
        totalPremiumPaid = getTotalPremiumPaid();
        premiumAmount = getPremiumAmount();
        policyNumber = getPolicyNumber();
        fundUnitA = getFundUnitA();
        fundUnitB = getFundUnitB();
        totalPremiumPaid += premiumAmount; // Increment total premium paid by the premium amount
        Funds fundA = Funds.getFundsByFundName(fundsList, fundNameA);
        Funds fundB = Funds.getFundsByFundName(fundsList, fundNameB);
        boolean withdrawalSuccess = false; // Flag to track if the premium payment was successful

        // Perform premium payment based on the policy type 
        if (policyType.equals("Investment-Linked Insurance Plan")) {
            // Retrieve unit price for Fund A and Fund B
            Funds.updateFundsToCSV("funds.csv", fundA.getFundName(), fundA.getUnitPrice());
            Funds.updateFundsToCSV("funds.csv", fundB.getFundName(), fundB.getUnitPrice());
            fundUnitA += (((premiumAmount / 100) * fundAllocationA) / fundA.getUnitPrice()); // increment Fund A's total fund units value by the fund units purchased after premium payment
            fundUnitB += (((premiumAmount / 100) * fundAllocationB) / fundB.getUnitPrice()); // increment Fund B's total fund units value by the fund units purchased after premium payment
            withdrawalSuccess = Transaction.deposit_Withdraw("Withdraw for insurance premium payment", scanner, userAccounts, premiumAmount);
        } else if (policyType.equals("Travel Insurance")) {
            System.out.println("Adventure Shield is an one-time payment policy. Premium payment is not required after policy inception."); // Travel insurance is one-time payment policy plan, no premium payment required
            return;
        } else if (policyType.equals("Health Insurance")) {
            // Check if premium payment is due for health insurance as it's premium frequency is annual
            if (ChronoUnit.YEARS.between(inception_date, LocalDate.now()) < 1) {
                System.out.println("Premium payment is not yet due, as the policy has not reached its first anniversary since the inception date. Please proceed with the payment after " + inception_date.plusYears(1) + ".");
                return;
            } else {
                withdrawalSuccess = Transaction.deposit_Withdraw("Withdraw for insurance premium payment", scanner, userAccounts, premiumAmount); // If premium is due, proceed with withdrawal for premium payment
            }
        } else if (policyType.equals("Traditional Insurance Plan")){
            withdrawalSuccess = Transaction.deposit_Withdraw("Withdraw for insurance premium payment", scanner, userAccounts, premiumAmount);
        }

        // Update insurance data after premium payment
        if (withdrawalSuccess) {
            // Update insurance data to CSV file
            updateInsuranceDataToCSV("insurances.csv", getPolicyNumber(), getPolicyStatus(), getTransactionAllowed(), getTotalWithdrawalAmount(), getTotalPremiumPaid(), getFundUnitA(), getFundUnitB());
            // Write premium payment tranction to CSV file
            TransactionsInsurance.writeTransaction("insuranceTransactions.csv", new TransactionsInsurance(policyNumber, "Premium Payment", LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss")), getPremiumAmount()));
            System.out.printf("Premium payment completed! Total premium payment for policy " + getPolicyNumber() + " is $%.2f.", totalPremiumPaid);
        } else {
            System.out.println("Error: Premium payment failed due to insufficient funds."); // Premium payment failed due to insufficient funds, thus no update required
        }
    }

    /**
     * Surrenders the insurance policy based on its type and certain conditions.
     * Refunds the premium amount paid to the investment account if applicable.
     *
     * @param scanner     The scanner object for input.
     * @param currentUser The current user object.
     */
    public void policySurrender(Scanner scanner, User currentUser) {
        List<Account> allAccounts = Account.loadAccountDataFromCSV("accounts.csv"); // Load all account data from CSV file
        List<Account> userAccounts = Account.getUserAccount(allAccounts, currentUser); // Get user acccounts from all accounts
        boolean transSuccessful = false; // Flag to track if the surrender transaction is successful
        totalWithdrawalAmount = totalPremiumPaid;
        
        // Check policy type and perform surrender based on policy types and conditions for each type
        if (policyType.equals("Travel Insurance")) {
            // Review period for Travel Insurance is 7 days. Surrender transaction will only allowed is date of request is within review period.
            if (ChronoUnit.DAYS.between(inception_date, LocalDate.now()) < 7) {
                System.out.println(policyNumber + " is currently within the review period, which extends up to 7 days before the inception date. Policy is surrendered and the premium amount paid will be refunded to your account.");
                transSuccessful = true;
            } else {
                System.out.println(policyNumber + " is not within the review period, which extends up to 7 days before the inception date. Thus, we are unable to surrender the policy");
            }
        } else if (policyType.equals("Health Insurance")) { // Review period for Health Insurance is 60 days. Surrender transaction will only allowed is date of request is within review period.
            if (ChronoUnit.DAYS.between(inception_date, LocalDate.now()) < 60) {
                System.out.println(policyNumber + " is currently within the review period, which extends up to 60 days before the inception date. Policy is surrendered and the premium amount paid will be refunded to your account.");
                transSuccessful = true;
            } else {
                System.out.println(policyNumber + " is not within the review period, which extends up to 60 days before the inception date. Thus, we are unable to surrender the policy.");
            }
        } else if (policyType.equals("Traditional Insurance Plan")) { // Surrender period for Traditional Insurance Plan is 2 years.
            transSuccessful = true;
            if (ChronoUnit.YEARS.between(inception_date, LocalDate.now()) < 2) {
                // If policy is surrendered before surrender period ends, surrender charge of 5% will be deducted from the total withdrawal amount. 
                totalWithdrawalAmount = 0.95 * totalWithdrawalAmount;
                System.out.println("As policy " + policyNumber + " is surrendered before it matures on " + maturity_date + ", a surrender charge of 5% of the total premium paid will be deducted to the Cash Surrender Value.\nThe Cash Surrender Value is $" + totalWithdrawalAmount + ". Policy is surrendered and the Cash Surrender Value will be credited to your account.");
            } else {
                // If policy is surrendered after surrender period (2 years), full amount for withdrawal will be credited.
                System.out.println("The Cash Surrender Value for policy " + policyNumber + " is $" + totalWithdrawalAmount + ". Policy is surrendered and the Cash Surrender Value will be credited to your account.");
            }
        } else if (policyType.equals("Investment-Linked Insurance Plan")) {
            transSuccessful = true;
            List<Funds> fundsList = Funds.loadFundDataFromCSV("funds.csv"); // Load funds from CSV file
            // Retrieve unit price for Fund A and Fund B
            Funds fundA = Funds.getFundsByFundName(fundsList, fundNameA);
            Funds fundB = Funds.getFundsByFundName(fundsList, fundNameB);
            Funds.updateFundsToCSV("funds.csv", fundA.getFundName(), fundA.getUnitPrice());
            Funds.updateFundsToCSV("funds.csv", fundB.getFundName(), fundB.getUnitPrice());
            totalWithdrawalAmount = ((getFundUnitA() * fundA.getUnitPrice()) + (getFundUnitB() * fundB.getUnitPrice())); // Calculate total withdrawal amount based on the sum of the values of fund units multiplied by their respective unit price declared as of transaction 
            // Surrender period for Investment-Linked Insurance Plan is 2 years.
            if (ChronoUnit.YEARS.between(inception_date, LocalDate.now()) < 2) {
                // If policy is surrendered before surrender period ends, surrender charge of 5% will be deducted from the total withdrawal amount. 
                totalWithdrawalAmount = 0.95 * totalWithdrawalAmount;
                System.out.printf("As policy " + policyNumber + " is surrendered before it matures on " + maturity_date + ", a surrender charge of 5%% of the Cash Surrender Value will be deducted.\nThe Cash Surrender Value is $%.2f.", totalWithdrawalAmount);
                System.out.println("Policy is surrendered and the Cash Surrender Value will be credited to your account.");
            } else {
                // If policy is surrendered after surrender period (2 years), full amount for withdrawal will be credited.
                System.out.printf("The Cash Surrender Value of policy ", policyNumber, " is $%.2f.", totalWithdrawalAmount + " Policy is surrendered and the Cash Surrender Value will be credited to your account.");
            }
        }
        // Update insurance data after policy surrender
        if (transSuccessful) {
            // Update insurance data to CSV file
            Transaction.deposit_Withdraw("Deposit the insurance payout", scanner, userAccounts, totalWithdrawalAmount);
            // Write premium payment tranction to CSV file
            TransactionsInsurance.writeTransaction("insuranceTransactions.csv", new TransactionsInsurance(policyNumber, "Policy Surrender", LocalDateTime.now().format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss")), totalWithdrawalAmount));
            updateInsuranceDataToCSV("insurances.csv", getPolicyNumber(), "Surrendered", false, getTotalWithdrawalAmount(), getTotalPremiumPaid(), getFundUnitA(), getFundUnitB());
        }
    }
}
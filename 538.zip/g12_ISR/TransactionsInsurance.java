import java.io.*;
import java.util.*;

/**
 * Represents transactions related to insurance policies.
*/
public class TransactionsInsurance {
    private int policyNumber;
    private String transactionType;
    private String logTime;
    private double transactionAmount;

    /**
     * Constructs a new TransactionsInsurance object.
     *
     * @param policyNumber      The policy number associated with the transaction.
     * @param transactionType   The type of transaction.
     * @param logTime           The timestamp of the transaction.
     * @param transactionAmount The amount involved in the transaction.
     */
    public TransactionsInsurance(int policyNumber, String transactionType, String logTime, double transactionAmount) {
        this.policyNumber = policyNumber;
        this.transactionType = transactionType;
        this.logTime = logTime;
        this.transactionAmount = transactionAmount;
    }

    /**
     * Retrieves the policy number associated with the transaction.
     *
     * @return The policy number.
     */
    public int getPolicyNumber() {
        return this.policyNumber;
    }

    /**
     * Retrieves the type of transaction.
     *
     * @return The transaction type.
     */
    public String getTransactionType() {
        return this.transactionType;
    }

    /**
     * Retrieves the timestamp of the transaction.
     *
     * @return The timestamp.
     */
    public String getLogTime() {
        return this.logTime;
    }

    /**
     * Retrieves the amount involved in the transaction.
     *
     * @return The transaction amount.
     */
    public double getTransactionAmount() {
        return this.transactionAmount;
    }

    /**
     * Retrieves all insurance transactions associated with a specific insurance policy.
     *
     * @param transInsurances The list of all insurance transactions.
     * @param insurance       The insurance policy to filter transactions.
     * @return The list of transactions associated with the specified insurance policy.
     */    
    public static List<TransactionsInsurance> getUserInsuranceTransactions(List<TransactionsInsurance> transInsurances, Insurance insurance) {
        return transInsurances.stream().filter(transactionInsurance -> transactionInsurance.getPolicyNumber()==insurance.getPolicyNumber()).toList();
    }

    /**
     * Loads insurance transaction data from a CSV file.
     *
     * @param filePath The path of the CSV file.
     * @return The list of insurance transactions loaded from the CSV file.
     */    
    public static List<TransactionsInsurance> loadInsuranceTransactionDataFromCSV(String filePath) {
        List<TransactionsInsurance> insuranceTransactionList = new ArrayList<>();
        try (Scanner csvScanner = new Scanner(new File(filePath))) {
            if (csvScanner.hasNextLine()) {
                csvScanner.nextLine();
            }
            while (csvScanner.hasNextLine()) {
                String[] tokens = csvScanner.nextLine().split(",");
                insuranceTransactionList.add(new TransactionsInsurance(Integer.parseInt(tokens[0]), tokens[1], tokens[2], Double.parseDouble(tokens[3])));
            }
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
        return insuranceTransactionList;
    }

    /**
     * Writes an insurance transaction to a CSV file.
     *
     * @param filePath The path of the CSV file.
     * @param t        The insurance transaction to be written.
     */    
    public static void writeTransaction(String filePath, TransactionsInsurance t) {
        try (BufferedWriter bw = new BufferedWriter(new FileWriter(filePath, true))) {
            StringBuilder sb = new StringBuilder();
            sb.append("\n" + t.getPolicyNumber() + "," + t.getTransactionType() + "," + t.getLogTime() + "," + t.getTransactionAmount());
            bw.write(sb.toString());
            System.out.println("Insurance transaction is updated in Transaction History.");
        } catch (Exception e) {
            System.out.println("Error!");
        }
    }
}
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * The Branch class represents a bank branch.
 */
public class Branch {
    private int branchCode;
    private String branchName;
    private String address;
    private String operatingHours;
    private int contactNumber;

    /**
     * Constructs a new Branch with the specified details. 
     * @param branchCode     the code of the branch
     * @param branchName     the name of the branch
     * @param address        the address of the branch
     * @param operatingHours the operating hours of the branch
     * @param contactNumber  the contact number of the branch
     */
    public Branch(int branchCode, String branchName, String address, String operatingHours, int contactNumber) {
        this.branchCode = branchCode;
        this.branchName = branchName;
        this.address = address;
        this.operatingHours = operatingHours;
        this.contactNumber = contactNumber;
    }

    /**
     * Retrieves the branch code.
     * @return the branch code
     */
    public int getBranchCode() {
        return branchCode;
    }

    /**
     * Retrieves the branch name.
     * @return the branch name
     */
    public String getBranchName() {
        return branchName;
    }

    /**
     * Retrieves the branch address.
     * @return the branch address
     */
    public String getAddress() {
        return address;
    }

    /**
     * Retrieves the operating hours of the branch.
     * @return the operating hours of the branch
     */
    public String getOperatingHours() {
        return operatingHours;
    }

    /**
     * Retrieves the contact number of the branch.
     * @return the contact number of the branch
     */
    public int getContactNumber() {
        return contactNumber;
    }

    /**
     * Reads branch information from a CSV file and returns a list of Branch objects.
     * @param filename the name of the CSV file containing branch information
     * @return a list of Branch objects read from the CSV file
     */
    public static List<Branch> readBranchFromCSV(String filename) {
        List<Branch> branchList = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(filename))) {
            String line;
            String headerLine = br.readLine();
            while ((line = br.readLine()) != null) {
                String[] data = line.split(",");
                int branchCode = Integer.parseInt(data[0]);
                String branchName = data[1];
                String address = data[2];
                int contactNumber = Integer.parseInt(data[3]);
                String operatingHours = data[4];

                Branch branch = new Branch(branchCode, branchName, address, operatingHours, contactNumber);
                branchList.add(branch);
            }
            // Sort branchName in ascending order
            Collections.sort(branchList, (b1, b2) -> b1.getBranchName().compareTo(b2.getBranchName()));
        } catch (IOException e) {
            e.printStackTrace();
        }

        return branchList;
    }
}
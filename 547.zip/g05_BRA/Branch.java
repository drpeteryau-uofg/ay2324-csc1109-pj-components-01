import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.Timer;

/**
 * Represents a branch with utilities for mapping between branch numbers and
 * names.
 */
public class Branch {
    private static final Map<String, String> branchNumberToNameMap = new HashMap<>();
    private static final Map<String, String> branchNameToNumberMap = new HashMap<>();
    private static Account account = new Account();

    static {
        // Initialize the branchNumberToNameMap and branchNameToNumberMap with branch
        // numbers and names
        branchNumberToNameMap.put("101", "ORCHARD");
        branchNumberToNameMap.put("102", "WOODLANDS");

        // Create the reverse mapping from branch name to branch number
        for (Map.Entry<String, String> entry : branchNumberToNameMap.entrySet()) {
            branchNameToNumberMap.put(entry.getValue(), entry.getKey());
        }

    }

    private String branchName, branchType, branchNumber, branchInvestment;
    boolean isFixedDepositSelected = false;

    /**
     * Constructs a Branch object with empty values for its attributes.
     */
    public Branch() {
        this.branchName = "";
        this.branchNumber = "";
        this.branchType = "";
        this.branchInvestment = "";
    }

    /**
     * Setter and Getter methods for managing branch information.
     */

    /**
     * Sets the name of the branch.
     *
     * @param branchName_input The name of the branch.
     */
    public void setBranchName(String branchName_input) {
        this.branchName = branchName_input;
    }

    /**
     * Sets the number of the branch based on the provided branch name using the
     * mapping above
     *
     * @param branchName_input The name of the branch.
     */
    public void setBranchNumber(String branchName_input) {
        this.branchNumber = getBranchNumberFromMap(branchName_input);
    }

    /**
     * Sets the type of the branch.
     *
     * @param branchType_input The type of the branch.
     */
    public void setBranchType(String branchType_input) {
        this.branchType = branchType_input;
    }

    /**
     * Sets the investment amount of the branch.
     *
     * @param investmentAmount The investment amount of the branch.
     */
    public void setBranchInvestment(String investmentAmount) {
        this.branchInvestment = investmentAmount;
    }

    /**
     * Changes the type of the branch.
     *
     * @param newBranchType The new type of the branch.
     */
    public void changeBranchType(String newBranchType) {
        this.branchType = newBranchType;
    }

    /**
     * Gets the name of the branch.
     *
     * @return The name of the branch.
     */
    public String getBranchName() {
        return branchNumberToNameMap.get(branchNumber);
    }

    /**
     * Gets the type of the branch.
     *
     * @return The type of the branch.
     */
    public String getBranchType() {
        return branchType;
    }

    /**
     * Gets the number of the branch.
     *
     * @return The number of the branch.
     */
    public String getBranchNumber() {
        return branchNumber;
    }

    /**
     * Gets the investment amount of the branch.
     *
     * @return The investment amount of the branch.
     */
    public String getBranchInvestment() {
        return branchInvestment;
    }

    /**
     * Retrieves the branch number based on the provided branch name.
     *
     * @param branchName The name of the branch.
     * @return The branch number if found, otherwise returns "-1".
     */
    public static String getBranchNumberFromMap(String branchName) {
        String branchNumber = branchNameToNumberMap.get(branchName);
        return branchNumber != null ? branchNumber : "-1"; // Return -1 if branch name not found
    }

    /**
     * Displays the investment menu for the given customer.
     * Allows the customer to view their investment options, including fixed deposit
     * and viewing current investments.
     * If the customer does not have an investment account, prompts them to switch
     * to an investment account.
     *
     * @param user_input The customer for whom the investment menu is displayed.
     */

    public void showInvestmentMenu(Customer user_input) {
        account.getAccList().clear();
        account.loadFromFile();
        Customer user = account.getAccount(user_input.getAccountNumber());
        if (user.getAccountType().equals("INVESTMENT")) {
            int choice = 0;
            JFrame frame = new JFrame("Current Investment Plan");
            frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
            frame.setSize(400, 400);
            frame.setLocationRelativeTo(null);
            String[] options = { "Fixed Deposit", "View your Investment" };
            choice = JOptionPane.showOptionDialog(null, "Select the investment to view:", "Investment Selection",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
            double investmentSum = Double.parseDouble(user.getBranchInvestment());

            switch (choice) {

                case 0:
                    if (investmentSum == 0) {
                        if (!isFixedDepositSelected) {
                            fixedDeposit(user);
                        }
                    } else if (investmentSum != 0 && isFixedDepositSelected == true)
                        JOptionPane.showMessageDialog(null,
                                "You have an ongoing fix deposit with us, Please wait until mature before investing again!");

                    if (investmentSum != 0 && isFixedDepositSelected == false) {
                        JOptionPane.showMessageDialog(null,
                                "Please withdraw your previous investment before starting new investment!");
                    }

                    break;
                case 1:
                    int selection = 0;
                    JFrame Viewframe = new JFrame("Your current Investment: " + user.getAccountBranchInvestment());
                    frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
                    frame.setSize(400, 400);
                    frame.setLocationRelativeTo(null);
                    String[] viewOptions = { "Withdraw investment", "Back" };
                    selection = JOptionPane.showOptionDialog(null,
                            "Your current Investment returns: " + user.getAccountBranchInvestment(),
                            "Choose your Action",
                            JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, viewOptions,
                            viewOptions[0]);
                    double matureValue = Double.parseDouble(user.getAccountBranchInvestment());

                    switch (selection) {
                        case 0:
                            double newBalance = user.getBankBalance() + matureValue;

                            if (matureValue == 0) {
                                JOptionPane.showMessageDialog(null, "No investment found!");
                                isFixedDepositSelected = false;
                            }

                            else if (matureValue > 0) {
                                String stringNewBalance = String.format("%.2f", newBalance);
                                user.setBankBalance(newBalance);
                                JOptionPane.showMessageDialog(null, "Your new Bank Balance is: " + stringNewBalance);
                                Account.updateCustomerDataFile(user.getAccountNumber(), "Bank Balance",
                                        stringNewBalance);
                                Branch.saveTransactionHistory(user.getAccountNumber(), "investment returns",
                                        matureValue, null, null, user);
                                // Set investment return back to 0
                                user.setBranchInvestment("0");
                                Account.updateCustomerDataFile(user.getAccountNumber(), "Bank Branch", "0");
                                account.getAccList().clear();
                                account.loadFromFile();

                            }

                            break;

                        case 1:
                            showInvestmentMenu(user_input);
                            break;

                        default:
                            break;
                    }
                    break;
                default:
                    break;
            }

        } else {
            Object[] options = { "Yes", "No" };
            int choice = JOptionPane.showOptionDialog(null,
                    "You do not have an investment account with us \n Do you wish to change to an investment account?",
                    "WARNING",
                    JOptionPane.DEFAULT_OPTION, JOptionPane.QUESTION_MESSAGE, null, options, options[0]);
            if (choice == 0) {
                String newAccountType = "INVESTMENT";
                user.changeAccountType(newAccountType);
                Account.updateCustomerDataFile(user.getAccountNumber(), "Account Type", newAccountType);
                JOptionPane.showMessageDialog(null, "Your account type has been changed succesfully!");
            } else {

            }
        }
    }

    /**
     * Initiates a fixed deposit for the given customer.
     * Prompts the user to input the principal amount and the number of years for
     * the deposit.
     * Calculates the maturity amount based on the principal amount, annual interest
     * rate, and compounding frequency.
     * Updates the user's bank balance, deducting the principal amount.
     * Updates the user's account information and saves transaction history.
     * Simulates the passage of time using a timer for the deposit maturity.
     * Allow user to withdraw the returns once deposit has mature
     *
     * @param user_input The customer initiating the fixed deposit.
     */

    public void fixedDeposit(Customer user_input) {
        double annualInterestRate = 0.034;
        int compoundingFrequency = 12; // Per Month
        int i = 0;
        Customer user = account.getAccount(user_input.getAccountNumber());

        double principal = Double.parseDouble(JOptionPane.showInputDialog("Enter the principal amount:"));
        if (principal > user.getBankBalance()) {
            JOptionPane.showMessageDialog(null, "You do not have sufficient fund in your bank.");

        } else if (principal <= user.getBankBalance()) {
            JOptionPane.showMessageDialog(null,
                    "You have entered " + principal + " as your principal amount");
            final int[] timeElapsed = new int[] { Integer.parseInt(
                    JOptionPane.showInputDialog("Enter the number of years you wish to hold for:")) };
            int numOfYears = timeElapsed[i];

            // Calculation of fixed deposit return
            double maturity = calFixedDeposit(principal, annualInterestRate, numOfYears,
                    compoundingFrequency);
            // Format to 2dp
            String decimalMaturity = String.format("%.2f", maturity);
            JOptionPane.showMessageDialog(null, "Your maturity is amounted to " + decimalMaturity
                    + " after " + timeElapsed[i] + " years.");

            // Deduct money and update bank balance
            double balance = user.getBankBalance() - principal;
            user.setBankBalance(balance);
            i = i + 1;

            // Change double to string
            String accountbalance = String.format("%.2f", balance);
            String principalInvestment = Double.toString(principal);

            Account.updateCustomerDataFile(user.getAccountNumber(), "Bank Balance", accountbalance);
            Account.updateCustomerDataFile(user.getAccountNumber(), "Bank Branch", principalInvestment);
            account.getAccList().clear();
            account.loadFromFile();
            JOptionPane.showMessageDialog(null, "Your remaining account balance: " + accountbalance);
            JOptionPane.showMessageDialog(null, "Thank you for banking with us!");

            Timer timer = new Timer(1000, null); // Fires every 1000 ms (1 second) for simulation purposes

            timer.addActionListener(e -> {
                user.setBranchInvestment(principalInvestment);
                int j = 0;
                timeElapsed[j]--; // Decrement years remaining

                if (timeElapsed[j] <= 0) {
                    // Stop the timer and calculate final maturity
                    timer.stop();

                    double maturityValue = calFixedDeposit(principal, annualInterestRate, numOfYears,
                            compoundingFrequency);
                    JOptionPane.showMessageDialog(null,
                            "Your investment has matured. Final amount: " + String.format("%.2f", maturityValue));
                    j = j + 1;
                    String stringMaturityValue = String.format("%.2f", maturityValue);
                    Account.updateCustomerDataFile(user.getAccountNumber(), "Bank Branch", stringMaturityValue);
                    user.setBranchInvestment(stringMaturityValue);
                    isFixedDepositSelected = false;
                } else {
                    // Optionally update the user on the status here
                    System.out.println("Year passed in simulation. " + timeElapsed[j] + " years remaining.");
                }
            }); // Start the simulation
            timer.start();
            i++;
            isFixedDepositSelected = true;
            Branch.saveTransactionHistory(user.getAccountNumber(), "investment deposit", principal, null, null, user);

        }

    }

    /**
     * Calculates the maturity amount of a fixed deposit based on the provided
     * parameters.
     *
     * @param principal            The principal amount of the fixed deposit.
     * @param annualInterestRate   The annual interest rate of the fixed deposit.
     * @param numberOfYears        The number of years the fixed deposit will be
     *                             held for.
     * @param compoundingFrequency The compounding frequency of interest.
     * @return The maturity amount of the fixed deposit after the specified period.
     */
    public double calFixedDeposit(double principal, double annualInterestRate, int numberOfYears,
            int compoundingFrequency) {
        double ratePerPeriod = annualInterestRate / compoundingFrequency;
        int totalPeriods = numberOfYears * compoundingFrequency;
        double maturityAmount = principal * Math.pow(1 + ratePerPeriod, totalPeriods);
        return maturityAmount;
    }

    /**
     * Saves a transaction record to the TransactionHistory.txt file.
     *
     * @param accountNumber          The account number associated with the
     *                               transaction.
     * @param actionType             The type of action, e.g., "investment deposit"
     *                               or "investment returns".
     * @param amount                 The amount involved in the transaction.
     * @param senderAccountNumber    The account number of the sender
     * @param recipientAccountNumber The account number of the recipient
     * @param user                   The customer involved in the transaction.
     */
    public static void saveTransactionHistory(String accountNumber, String actionType, double amount,
            String senderAccountNumber, String recipientAccountNumber, Customer user) {
        try (PrintWriter writer = new PrintWriter(new FileWriter("TransactionHistory.txt", true))) {
            SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
            String dateTime = dateFormat.format(new Date());

            // Display Bank balance in 2dp instead
            String formatBalance = String.format("%.2f", user.getBankBalance());
            double parsedBalance = Double.parseDouble(formatBalance);

            switch (actionType) {
                case ("investment deposit"):
                    writer.println("Transaction Datetime: " + dateTime + ", Account Number: " + accountNumber
                            + ", Action Type: " + actionType + ", Amount: -"
                            + amount + ", New Balance: " + parsedBalance);
                    JOptionPane.showMessageDialog(null, "Transaction recorded successfully!", "Success",
                            JOptionPane.INFORMATION_MESSAGE);
                    break;
                case ("investment returns"):
                    writer.println("Transaction Datetime: " + dateTime + ", Account Number: " + accountNumber
                            + ", Action Type: " + actionType + ", Amount: +"
                            + amount + ", New Balance: " + parsedBalance);
                    JOptionPane.showMessageDialog(null, "Transaction recorded successfully!", "Success",
                            JOptionPane.INFORMATION_MESSAGE);
                    break;
                default:
                    break;
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error writing transaction history. Please try again", "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
}

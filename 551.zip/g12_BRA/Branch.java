import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

/**
 * The Branch class represents a branch in a bank.
 * It contains information about the branch such as its ID, name, and options a branch has to offer the customers.
 * It also provides static methods to manage a list of branches.
 */
public class Branch {
    private int branchId; // Unique identifier for the branch
    private String branchName; // Name of the branch

    // Additional attributes for branch-specific options
    private boolean hasInsuranceOption;
    private boolean hasSettingsOption;

    // List to store branches
    private static List<Branch> branchList = new ArrayList<>();

    /**
     * Constructor to initialize branch attributes.
     *
     * @param branchId              Unique identifier for the branch.
     * @param branchName            Name of the branch.
     * @param hasInsuranceOption    Indicates if the branch has insurance management options.
     * @param hasSettingsOption     Indicates if the branch has settings options to change pin or limit.
     */
    public Branch(int branchId, String branchName, boolean hasInsuranceOption, boolean hasSettingsOption) {
        this.branchId = branchId;
        this.branchName = branchName;
        this.hasInsuranceOption = hasInsuranceOption;
        this.hasSettingsOption = hasSettingsOption;
    }

    /**
     * Getter method for the branch ID.
     *
     * @return the branch ID.
     */
    public int getBranchId() {
        return branchId;
    }

    /**
     * Getter method for the branch name.
     *
     * @return the branch name.
     */
    public String getBranchName() {
        return branchName;
    }

    /**
     * Method to display branch information.
     * Prints the branch ID and name to the console.
     */
    public void displayBranchInfo() {
        System.out.println("\nBranch ID: " + branchId);
        System.out.println("Branch Name: " + branchName);
    }

    /**
     * Static method to add a new branch to the list.
     *
     * @param branch the branch to be added.
     */
    public static void addBranch(Branch branch) {
        branchList.add(branch);
    }

    /**
     * Getter method for the insurance option availability.
     *
     * @return true if the branch has insurance options, false otherwise.
     */
    public boolean hasInsuranceOption() {
        return hasInsuranceOption;
    }

    /**
     * Getter method for the settings option availability.
     *
     * @return true if the branch has settings options, false otherwise.
     */
    public boolean hasChangePinOption() {
        return hasSettingsOption;
    }

    /**
     * Static method to get a branch based on branch ID.
     *
     * @param branchId the ID of the branch to find.
     * @return the Branch object if found, null otherwise.
     */
    public static Branch getBranchById(int branchId) {
        for (Branch branch : branchList) {
            if (branch.getBranchId() == branchId) {
                return branch;
            }
        }
        return null;
    }

    /**
     * Static method to generate menu options based on branch-specific features.
     *
     * @param branch the branch for which to generate menu options.
     * @return a list of menu options available for the branch.
     */
    public static List<String> generateMenuOptions(Branch branch) {
        List<String> options = new ArrayList<>();
        options.add("View Balance");
        options.add("Deposit");
        options.add("Withdraw");
        options.add("Transfer");
        options.add("Transaction History");
        if (branch.hasInsuranceOption) {
            options.add("Insurance");
        }
        if (branch.hasSettingsOption) {
            options.add("Change Pin or Limit");
        }
        options.add("Logout");
        return options;
    }

    /**
     * Static method to initialize branches from a CSV file.
     *
     * @param fileName the name of the CSV file containing branch data.In this case being branches.csv
     */
    public static void initializeBranchesFromCSV(String fileName) {
        List<Branch> branches = new ArrayList<>();
        try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
            String line;
            // Skip the header line
            reader.readLine();
            while ((line = reader.readLine()) != null) {
                // Check by , delimeter
                String[] branchDetails = line.split(",");
                int branchId = Integer.parseInt(branchDetails[0]);
                String branchName = branchDetails[1];
                boolean hasInsuranceOption = Boolean.parseBoolean(branchDetails[2]);
                boolean hasSettingsOption = Boolean.parseBoolean(branchDetails[3]);
                branches.add(new Branch(branchId, branchName, hasInsuranceOption, hasSettingsOption));
            }
        } catch (IOException e) {
            System.out.println("Error reading the CSV file: " + e.getMessage());
        }
        // Replace the existing branchList with the new one
        branchList = branches;
    }

    /**
     * Static method to let the user select a branch.
     * Displays a list of available branches and prompts the user to enter a branch ID.
     * If the entered branch ID is valid, returns the corresponding Branch object.
     * If the entered branch ID is invalid (non-numeric or not found in the branch list),
     * prompts the user to try again until a valid branch is selected.
     *
     * @param scanner the Scanner object to read user input.
     * @return the selected Branch object, or null if input is invalid.
     */
    public static Branch selectBranch(Scanner scanner){
        while (true) {
            try {
                System.out.println("Select a branch:");
                for (Branch branch : branchList) { // Display available branches
                    branch.displayBranchInfo();
                }
                System.out.print("Enter the branch ID: ");
                int selectedBranchId = Integer.parseInt(scanner.next());
                Branch selectedBranch = getBranchById(selectedBranchId);
                //If user entered branch found, assign the branch object. Else re-prompt.
                if (selectedBranch != null) {
                    return selectedBranch; // Valid branch selected, exit the loop
                } else {
                    System.out.println("Invalid branch ID. Please select a valid branch.");
                }
            } catch (NumberFormatException e) {
                System.out.println("Invalid input. Please enter a valid numeric value.");
            }
        }
    }
}

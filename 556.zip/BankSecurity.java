import java.awt.event.ActionListener;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.security.spec.InvalidKeySpecException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Base64;
import java.util.Date;

import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.swing.JOptionPane;
import javax.swing.JPasswordField;
import javax.swing.Timer;

/**
 * The BankSecurity class handles security-related functionalities for a banking system,
 * including password hashing, login/logout activities logging, account blocking, and more.
 * It utilizes various encryption and hashing techniques for secure data handling.
 * <p>
 * This class also manages customer account data loading from a file, recording login/logout activities,
 * and enforcing security measures such as failed login attempt tracking and account blocking.
 * </p>
 *
 * @author [Author Name]
 * @version [Version Number]
 */


public class BankSecurity {
   // Constants
    private static final int SALT_LENGTH = 16; // Length of the salt in bytes
    private static final int ITERATIONS = 10000; // Number of iterations for PBKDF2
    // Attributes
    private ArrayList<Customer> accList;
    private Timer autoLogoutTimer;
    private int failedLoginCount = 0;

    public BankSecurity(){
        accList = new ArrayList<>();
        loadFromFile(); // Directly load data into the accList
    }

     /**
     * Retrieves the list of customer accounts.
     *
     * @return The list of customer accounts.
     */

    public ArrayList<Customer> getAccList() {
        return accList;
    }

    /**
     * Starts an automatic logout timer with the specified delay and ActionListener.
     *
     * @param delay    The delay in milliseconds before the ActionListener is called.
     * @param listener The ActionListener to be called when the timer expires.
     */

    public void startAutoLogoutTimer(int delay, ActionListener listener) {
        autoLogoutTimer = new Timer(delay, listener);
        autoLogoutTimer.setRepeats(false);
        autoLogoutTimer.start();
    }

    /**
     * Loads account data from a customer data file into the program.
     * Parses the file and constructs Customer objects to populate the accList ArrayList.
     */
    public void loadFromFile() {
        try (BufferedReader reader = new BufferedReader(new FileReader("customerdata.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] fields = line.split(",");
                if (fields.length == 15) { // Check if all fields are present
                    String accountNumber = fields[0];
                    String accountName = fields[1];
                    String password = fields[2];
                    double bankBalance = Double.parseDouble(fields[3]);
                    double transferLimit = Double.parseDouble(fields[4]);
                    double withdrawalLimit = Double.parseDouble(fields[5]);
                    String phoneNo = fields[6];
                    String accountBranch = fields[11];
                    String branchNumber = fields[12];
                    String accountType = fields[13];
                    String branchInvestment = fields[14];

                    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                    Date createDate = null;
                    if (!fields[7].isEmpty()) {
                        createDate = dateFormat.parse(fields[7]);
                    }

                    String accStatus = fields[8];

                    Date closeDate = null;
                    if (!fields[9].isEmpty()) {
                        closeDate = dateFormat.parse(fields[9]);
                    }
                    String salt = fields[10];

                    Customer customer = new Customer(accountNumber, accountName, password, bankBalance, transferLimit,
                            withdrawalLimit, phoneNo, createDate, accStatus, closeDate, salt, accountBranch,
                            branchNumber, accountType, branchInvestment);

                    accList.add(customer);
                }
            }

        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "Error loading user data from file: " + e.getMessage(), "Error",
                    JOptionPane.ERROR_MESSAGE);
        } catch (ParseException e) {
            JOptionPane.showMessageDialog(null, "Error parsing date from file: " + e.getMessage(), "Error",
                    JOptionPane.ERROR_MESSAGE);
        }
    }
    
    /**
 * Writes a login activity log entry for the specified account number.
 *
 * @param accountNumber The account number associated with the login activity.
 */
    public static void writeLoginActivity(String accountNumber) {
    	try (PrintWriter writer = new PrintWriter(new FileWriter("ActivityLog.txt", true))) {
    		
    		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    		Date loginDate = new Date();
    		String formattedLoginDate = dateFormat.format(loginDate);
    		
    		writer.println(formattedLoginDate + "," + "login" + "," + accountNumber);
    		
    		
    	} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }

    /**
 * Writes a failed login activity log entry for the specified account number.
 *
 * @param accountNumber The account number associated with the failed login activity.
 */
    public static void writeFailedActivity(String accountNumber) {
    	try (PrintWriter writer = new PrintWriter(new FileWriter("ActivityLog.txt", true))) {
    		
    		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    		Date loginDate = new Date();
    		String formattedLoginDate = dateFormat.format(loginDate);
    		
    		writer.println(formattedLoginDate + "," + "FailedLogin" + "," + accountNumber);
    		
    		
    	} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }
    
    /**
 * Writes a logout activity log entry for the specified customer.
 *
 * @param currentUser The Customer object representing the logged-out user.
 */

    public static void writeLogOutActivity(Customer currentUser) {
    	try (PrintWriter writer = new PrintWriter(new FileWriter("ActivityLog.txt", true))) {
    		
    		SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    		Date logoutDate = new Date();
    		String formattedLogoutDate = dateFormat.format(logoutDate);
    		
    		String accountToLogOut = currentUser.getAccountNumber();    	
    		
    		writer.println(formattedLogoutDate + "," + "logout" + "," + accountToLogOut);
    		
    		
    	} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
    }


    /**
 * Generates a random salt and hashes the provided password using PBKDF2.
 *
 * @param password The password to be hashed.
 * @return An array containing the hashed password and the corresponding salt.
 * @throws NoSuchAlgorithmException If the specified cryptographic algorithm is not available.
 * @throws InvalidKeySpecException  If the provided key specification is invalid.
 */

    public static String[] generateSaltAndHashPassword(String password)
            throws NoSuchAlgorithmException, InvalidKeySpecException {
        byte[] salt = generateSalt();
        String hashedPassword = hashPassword(password, salt);
        return new String[]{hashedPassword, Base64.getEncoder().encodeToString(salt)};
    }

    /**
 * Generates a random salt of the specified length.
 *
 * @return The generated salt as a byte array.
 */

    private static byte[] generateSalt() {
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[SALT_LENGTH];
        random.nextBytes(salt);
        return salt;
    }

    /**
 * Hashes the provided password using PBKDF2 with the given salt.
 *
 * @param password The password to be hashed.
 * @param salt     The salt used for hashing.
 * @return The hashed password as a string.
 * @throws NoSuchAlgorithmException If the specified cryptographic algorithm is not available.
 * @throws InvalidKeySpecException  If the provided key specification is invalid.
 */
    private static String hashPassword(String password, byte[] salt)
            throws NoSuchAlgorithmException, InvalidKeySpecException {
        // Perform password-based key derivation
        PBEKeySpec spec = new PBEKeySpec(password.toCharArray(), salt, ITERATIONS, 64 * 8); // 64 * 8 = 512-bit key
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
        byte[] hash = factory.generateSecret(spec).getEncoded();
        return Base64.getEncoder().encodeToString(hash);
    }

  
    /**
 * Verifies if the provided password matches the given hashed password and salt.
 *
 * @param password       The password to be verified.
 * @param saltString     The salt used for hashing the password.
 * @param hashedPassword The hashed password to be verified against.
 * @return True if the password matches the hashed password; otherwise, false.
 * @throws NoSuchAlgorithmException If the specified cryptographic algorithm is not available.
 * @throws InvalidKeySpecException  If the provided key specification is invalid.
 */
    public static boolean verifyPassword(String password, String saltString, String hashedPassword)
            throws NoSuchAlgorithmException, InvalidKeySpecException {
        // Convert salt string to byte array
        byte[] salt = Base64.getDecoder().decode(saltString);

        // Hash the provided password with the given salt
        String generatedHash = hashPassword(password, salt);

        // Check if the generated hash matches the provided hashed password
        return generatedHash.equals(hashedPassword);
    }


    /**
 * Prompts the user to set a password and validates the input according to specified criteria.
 *
 * @param prompt The prompt message for setting the password.
 * @return The password set by the user if it meets the criteria; otherwise, null.
 */
    public static String setPassword(String prompt) {
        while (true) {
            JPasswordField passwordField = new JPasswordField();
            int option = JOptionPane.showConfirmDialog(null, passwordField, prompt, JOptionPane.OK_CANCEL_OPTION);

            if (option == JOptionPane.OK_OPTION) {
                char[] passwordChars = passwordField.getPassword();
                String password = new String(passwordChars);

                // Check if the password meets the criteria
                if (password.length() < 6 ||
                    password.length() > 14 ||
                    !password.matches(".*[A-Z].*") ||
                    !password.matches(".*[a-z].*") ||
                    !password.matches(".*\\d.*") ||
                    !password.matches(".*[^A-Za-z0-9].*")) {
                    JOptionPane.showMessageDialog(null, "Password must be between 6 and 14 characters long and contain at least one uppercase letter, one lowercase letter, one digit, and one symbol.", "Invalid Password", JOptionPane.ERROR_MESSAGE);
                  
                    
                } else {
                    return password; // Password meets criteria
                }
            } else {
                // User canceled input
                return null;
            }
        }
    }

    /**
 * Prompts the user to enter a password.
 *
 * @return The password entered by the user.
 */
    public static String getPassword() {
        JPasswordField passwordField = new JPasswordField();
        int option = JOptionPane.showConfirmDialog(null, passwordField, "Enter Password", JOptionPane.OK_CANCEL_OPTION);
    
        if (option == JOptionPane.OK_OPTION) {
            char[] passwordChars = passwordField.getPassword();
            return new String(passwordChars);
        } else {
            // User canceled input or closed the dialog
            return null;
        }
    }
    
    
/**
 * Prompts the user to set a phone number and validates the input format.
 *
 * @param prompt The prompt message for setting the phone number.
 * @return The valid phone number entered by the user.
 */
    public static String setPhoneNumber(String prompt) {
        while (true) {
            String phoneNo = JOptionPane.showInputDialog(null, prompt);
            // Validate the phone number format
            if (phoneNo.matches("[89]\\d{7}")) { // Pattern: First digit is 8 or 9, followed by 7 digits
                return phoneNo; // Return the valid phone number
            } else {
                JOptionPane.showMessageDialog(null, "Invalid phone number format. Please enter an 8-digit number starting with 8 or 9.", "Invalid Phone Number", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /**
 * Prompts the user to set a name and validates the input format.
 *
 * @param prompt The prompt message for setting the name.
 * @return The valid name entered by the user.
 */
    public static String setName(String prompt) {
        while (true) {
            String name = JOptionPane.showInputDialog(null, prompt);
        
            // Validate the name format
            if (name.matches("[a-zA-Z ]{1,15}")) {
                return name.trim(); // Return the valid name (trim to remove leading and trailing whitespace)
            } else {
                JOptionPane.showMessageDialog(null, "Invalid name format. Please enter alphabetic characters only (maximum 15 characters).", "Invalid Name", JOptionPane.ERROR_MESSAGE);
            }
        }
    }
    

    /**
 * Prompts the user to set an account number and validates the input format.
 *
 * @param prompt The prompt message for setting the account number.
 * @return The valid account number entered by the user.
 */
    public static String setAccountNumber(String prompt) {
        while (true) {
            String accountNumber = JOptionPane.showInputDialog(null, prompt);
            // Validate the account number format
            if (accountNumber.matches("\\d{3}-\\d{10}")) { // Pattern: Three digits followed by a hyphen and ten digits
                return accountNumber; // Return the valid account number
            } else {
                JOptionPane.showMessageDialog(null, "Invalid account number format. Please input correctly Eg. '101-1708233298'.", "Invalid Account Number", JOptionPane.ERROR_MESSAGE);
            }
        }
    }

    /**
 * Checks if the specified account has exceeded the allowed number of failed login attempts.
 *
 * @param accountNumber The account number to check for failed login attempts.
 * @return True if the account has exceeded the limit; otherwise, false.
 */
    public boolean hasExceededFailedLoginAttempts(String accountNumber) {
        try (BufferedReader br = new BufferedReader(new FileReader("ActivityLog.txt"))) {
            String line;
            int failedAttempts = 0;
            while ((line = br.readLine()) != null) {
                if (line.contains("FailedLogin") && line.contains(accountNumber)) {
                    failedAttempts++;
                }
            }
            return failedAttempts >= 5; // Change the limit as needed
    
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "An error occurred while reading the activity log file: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
            return false; // Return false if an error occurs while reading the file
        }
    }

    /**
 * Removes failed login history entries for a specific account from the activity log file.
 *
 * @param accountNumber The account number for which failed login history is to be removed.
 */
    public static void removeFailedLoginHistory(String accountNumber) {
        try {
            File inputFile = new File("ActivityLog.txt");
            File tempFile = new File("TempActivityLog.txt");

            BufferedReader reader = new BufferedReader(new FileReader(inputFile));
            BufferedWriter writer = new BufferedWriter(new FileWriter(tempFile));

            String lineToRemove = "FailedLogin," + accountNumber;

            String currentLine;
            while ((currentLine = reader.readLine()) != null) {
                // Remove the line if it contains the failed login history for the specified account
                if (currentLine.contains(lineToRemove)) continue;
                writer.write(currentLine + System.getProperty("line.separator"));
            }
            writer.close();
            reader.close();

        // Replace the original file with the temporary file
            if (!inputFile.delete()) {
                JOptionPane.showMessageDialog(null, "Failed to delete the original activity log file.", "Error", JOptionPane.ERROR_MESSAGE);
                return;
            }
            if (!tempFile.renameTo(inputFile)) {
                JOptionPane.showMessageDialog(null, "Failed to rename the temporary activity log file.", "Error", JOptionPane.ERROR_MESSAGE);
            }
        } catch (IOException e) {
            JOptionPane.showMessageDialog(null, "An error occurred while removing failed login history: " + e.getMessage(), "Error", JOptionPane.ERROR_MESSAGE);
        }
    }
    

    /**
 * Increments the count of failed login attempts.
 */
    public void countFailedLoginAttempt() {
    	failedLoginCount++;
    }

    /**
 * Retrieves the number of failed login attempts.
 *
 * @return The number of failed login attempts.
 */
    
    public int getNoOfFailedAttempts() {
    	return failedLoginCount;
    }
    
    /**
 * Resets the count of failed login attempts to zero.
 */
    public void resetFailedLoginCounter() {
    	failedLoginCount = 0;
    }
    
    /**
 * Blocks the specified account by updating its status and close date.
 *
 * @param c The Customer object representing the account to be blocked.
 */
    public void blockAccount(Customer c) {
    	c.setAccStatus("Blocked");
    	
    	SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		Date blockedDate = new Date();
		c.setCloseDate(blockedDate);
		String formattedBlockedDate = dateFormat.format(c.getCloseDate());
		
		Account.updateCustomerDataFile(c.getAccountNumber(),"Closed Date", formattedBlockedDate);
    	Account.updateCustomerDataFile(c.getAccountNumber(), "Status", c.getAccStatus());
		
    }

    
}

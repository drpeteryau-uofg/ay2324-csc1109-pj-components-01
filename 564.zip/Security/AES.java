import javax.crypto.Cipher;
import javax.crypto.SecretKey;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.SecureRandom;
import java.security.spec.KeySpec;
import java.util.Base64;
import java.io.UnsupportedEncodingException;

/**
 * The AES class provides methods for encrypting and decrypting strings using
 * the AES algorithm.
 */
public class AES {

  private static final int KEY_LENGTH = 256;
  private static final int ITERATION_COUNT = 65536;

  /**
   * Encrypts a string using the AES algorithm.
   *
   * @param strToEncrypt The string to be encrypted.
   * @param secretKey    The secret key used for encryption.
   * @param salt         The salt used for encryption.
   * @return The encrypted string.
   */
  public static String encrypt(String strToEncrypt, String secretKey, String salt) {
    try {
      Cipher cipher = setupEncryption(secretKey, salt);
      return performEncryption(strToEncrypt, cipher);
    } catch (Exception e) {
      throw new RuntimeException("Error during encryption", e);
    }
  }

  /**
   * Sets up the encryption cipher with the given secret key and salt.
   *
   * @param secretKey The secret key used for encryption.
   * @param salt      The salt used for encryption.
   * @return The encryption cipher.
   * @throws Exception If an error occurs during setup.
   */
  private static Cipher setupEncryption(String secretKey, String salt) throws Exception {
    SecureRandom secureRandom = new SecureRandom();
    byte[] iv = new byte[16];
    secureRandom.nextBytes(iv);
    IvParameterSpec ivspec = new IvParameterSpec(iv);

    SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
    KeySpec spec = new PBEKeySpec(secretKey.toCharArray(), salt.getBytes(), ITERATION_COUNT, KEY_LENGTH);
    SecretKey tmp = factory.generateSecret(spec);
    SecretKeySpec secretKeySpec = new SecretKeySpec(tmp.getEncoded(), "AES");

    Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
    cipher.init(Cipher.ENCRYPT_MODE, secretKeySpec, ivspec);

    return cipher;
  }

  /**
   * Performs the encryption of the given string using the provided cipher.
   *
   * @param strToEncrypt The string to be encrypted.
   * @param cipher       The encryption cipher.
   * @return The encrypted string.
   * @throws Exception If an error occurs during encryption.
   */
  private static String performEncryption(String strToEncrypt, Cipher cipher) throws Exception {
    byte[] cipherText = cipher.doFinal(strToEncrypt.getBytes("UTF-8"));
    byte[] iv = cipher.getIV();
    byte[] encryptedData = new byte[iv.length + cipherText.length];
    System.arraycopy(iv, 0, encryptedData, 0, iv.length);
    System.arraycopy(cipherText, 0, encryptedData, iv.length, cipherText.length);

    return Base64.getEncoder().encodeToString(encryptedData);
  }

  /**
   * Decrypts a string using the AES algorithm.
   *
   * @param strToDecrypt The string to be decrypted.
   * @param secretKey    The secret key used for decryption.
   * @param salt         The salt used for decryption.
   * @return The decrypted string.
   */
  public static String decrypt(String strToDecrypt, String secretKey, String salt) {
    try {
      byte[] encryptedData = Base64.getDecoder().decode(strToDecrypt);
      Cipher cipher = setupDecryption(secretKey, salt, encryptedData);
      return performDecryption(encryptedData, cipher);
    } catch (Exception e) {
      throw new RuntimeException("Error during decryption", e);
    }
  }

  /**
   * Sets up the decryption cipher with the given secret key and salt.
   *
   * @param secretKey     The secret key used for decryption.
   * @param salt          The salt used for decryption.
   * @param encryptedData The encrypted data to be decrypted.
   * @return The decryption cipher.
   * @throws Exception If an error occurs during setup.
   */
  private static Cipher setupDecryption(String secretKey, String salt, byte[] encryptedData) throws Exception {
    byte[] iv = new byte[16];
    System.arraycopy(encryptedData, 0, iv, 0, iv.length);
    IvParameterSpec ivspec = new IvParameterSpec(iv);

    SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256");
    KeySpec spec = new PBEKeySpec(secretKey.toCharArray(), salt.getBytes(), ITERATION_COUNT, KEY_LENGTH);
    SecretKey tmp = factory.generateSecret(spec);
    SecretKeySpec secretKeySpec = new SecretKeySpec(tmp.getEncoded(), "AES");

    Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
    cipher.init(Cipher.DECRYPT_MODE, secretKeySpec, ivspec);

    return cipher;
  }

  /**
   * Performs the decryption of the given encrypted data using the provided cipher.
   *
   * @param encryptedData The encrypted data to be decrypted.
   * @param cipher        The decryption cipher.
   * @return The decrypted string.
   * @throws Exception If an error occurs during decryption.
   */
  private static String performDecryption(byte[] encryptedData, Cipher cipher) throws Exception {
    byte[] cipherText = new byte[encryptedData.length - 16];
    System.arraycopy(encryptedData, 16, cipherText, 0, cipherText.length);

    byte[] decryptedText = cipher.doFinal(cipherText);
    return new String(decryptedText, "UTF-8");
  }

}

import java.security.NoSuchAlgorithmException;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * The Security class represents the security features of a banking system.
 * It contains methods and attributes related to card ID, PIN number, email,
 * locking status,
 * encryption key, salt, OTP code, OTP expiry, and secret key.
 * Dependant on the generateKey class and AES class.
 * @version 1.0
 */
public class Security {

    private String _cardID;
    /**
     * This value is to store the hashed PIN number.
     */
    private String _PIN_Number;
    private String _Email;
    /**
     * This value is to check if the account is locked.
     */
    private boolean _isLocked;
    /**
     * This is to get the cipher key from the AES encryption class.
     * Requires secret key and salt to be set before calling this method.
     */
    private String _cipherKey;
    /** 
     * This is to get the salt from the generateKey class.
     * Needed for cipherKey generation and hash value generation.
     */
    private String _salt;
    /**
     * This is to get the OTP code from the generateKey class.
     */
    private int _otpCode;
    /**
     * This is to get the OTP expiry which is 5 mins from the current time.
     */
    private LocalDateTime _otpExpiry;
    /**
     * This is to get the secret key from the generateKey class.
     * This is also used for Cipher key generation.
     */
    private String _secretKey;
    /**
     * This is to get the hash value from the generateKey class.
     * Requires salt to be set before calling this method.
     */
    private String _hashValue;

    /**
     * This method is used to get the card ID.
     * 
     * @return String This returns the card ID.
     */
    public String get_cardID() {
        return _cardID;
    }

    /**
     * This method is used to set the card ID.
     * 
     * @param cardID A string representing the card ID.
     */
    public void set_cardID(String cardID) {
        this._cardID = cardID;
        System.out.println("Card ID has been set to " + cardID);
    }

    /**
     * This method is used to get the PIN number.
     * 
     * @return int This returns the PIN number.
     */
    public String get_PIN_Number() {
        return _PIN_Number;
    }

    /**
     * This method is used to set the PIN number.
     * 
     * @param PIN_Number An integer representing the PIN number.
     */
    public void set_PIN_Number(int PIN_Number) {
        set_hashValue(Integer.toString(PIN_Number));
        this._PIN_Number = get_hashValue();
        System.out.println("PIN has been set to hash value of " + get_hashValue());
    }

    /**
     * This method is used to compare the plain PIN with the stored PIN.
     * 
     * @param plainPIN An integer representing the plain PIN.
     * @return boolean This returns true if the plain PIN matches the stored PIN.
     */
    public boolean comparePIN(int plainPIN) {
        set_hashValue(Integer.toString(plainPIN));
        return (get_hashValue() == get_PIN_Number() ? true : false);
    }

    /**
     * This method is used to get the email.
     * 
     * @return String This returns the email.
     */

    public String get_Email() {
        return _Email;
    }

    /**
     * This method is used to set the email.
     * 
     * @param email A string representing the email.
     */
    public void set_Email(String email) {
        _Email = email;
        System.out.println("Email has been set to " + email);
    }

    /**
     * This method is used to check if the account is locked.
     * 
     * @return boolean This returns true if the account is locked.
     */
    public boolean return_isLocked() {
        return _isLocked;
    }

    /**
     * This method is used to set the account lock status.
     * 
     * @param isLocked A boolean representing the lock status.
     */
    public void set_isLocked(boolean isLocked) {
        this._isLocked = isLocked;
    }

    /**
     * This method is used to get the cipher key.
     * 
     * @return String This returns the cipher key.
     */
    public String get_cipherKey() {
        return _cipherKey;
    }

    /**
     * This method is used to set the cipher key with AES encryption class.
     * Secret key and salt should be set before calling this method.
     * @see AES
     * @param plainText A string representing the plain text to be encrypted.
     */
    public void set_cipherKey(String plainText) {
        if(get_secretKey() == null || get_salt() == null){
            set_secretKey();
            set_salt();
        }
        this._cipherKey = AES.encrypt(plainText, get_secretKey(), get_salt());
        System.out.println("Cipher key has been set to " + get_cipherKey());
    }

    /**
     * This method is used to get the salt.
     * 
     * @return String This returns the salt.
     */
    public String get_salt() {
        return _salt;
    }

    /**
     * This method is used to set the salt and stores it as a string
     * @see generateKey
     */
    public void set_salt() {
        this._salt = generateKey.generateSalt();
        System.out.println("Salt has been set to " + get_salt());
    }

    /**
     * This method is used to get the OTP code.
     * 
     * @return int This returns the OTP code.
     */
    public int get_otpCode() {
        return _otpCode;
    }

    /**
     * This method is used to set the OTP code.
     * @see generateKey
     */
    public void set_otpCode() {
        this._otpCode = generateKey.generateOTP();
        System.out.println("OTP has been set to " + get_otpCode());
    }

    /**
     * This method is used to get the OTP expiry.
     * 
     * @return LocalDateTime This returns the OTP expiry.
     */
    public LocalDateTime get_otpExpiry() {
        return _otpExpiry;
    }

    /**
     * This method is used to set the OTP expiry.
     */
    public void set_otpExpiry() {
        this._otpExpiry = LocalDateTime.now().plusMinutes(5);
        System.out.println("OTP expiry has been set to " + DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss").format(get_otpExpiry()));
    }

    /**
     * This method is used to get the secret key.
     * 
     * @return String This returns the secret key.
     */
    public String get_secretKey() {
        return _secretKey;
    }

    /**
     * This method is used to set the secret key with AES encryption class.
     * @see generateKey
     */
    public void set_secretKey() {
        try {
            _secretKey = generateKey.generateSecretKey();
            System.out.println("Secret key has been set to " + get_secretKey());
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
    }

    /**
     * This method is used to get the hash value.
     * 
     * @return String This returns the hash value.
     */
    public String get_hashValue() {
        return _hashValue;
    }

    /**
     * This method is used to set the hash value with SHA-512 algorithm.
     * Salt should be set before calling this method.
     * @param plainText A string representing the plain text to be hashed.
     * @see generateKey
     */
    public void set_hashValue(String plainText) {
        if(get_salt() == null){
            set_salt();
        }
        try {
            this._hashValue = generateKey.generateHashValue(get_salt(), plainText);
            System.out.println("Hash value has been set to " + get_hashValue());
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
    }
    /**
     * This method is used to toggle the lock status of the account.
     */
    public void toggleLockedStatus() {
        set_isLocked(!return_isLocked());
    }

    /**
     * This method is used to verify the OTP code.
     * 
     * @param otp An integer representing the OTP code.
     * @return boolean This returns true if the OTP code is verified.
     */
    public boolean verifyOTP(int otp) {
        return otp == get_otpCode() ? true : false;
    }

    /**
     * This method is used to compare the OTP expiry with the current time.
     * 
     * @return boolean This returns true if the OTP is expired.
     */
    public boolean compareExpiry() {
        return LocalDateTime.now().isAfter(get_otpExpiry()) ? true : false;
    }

    /**
     * This method is used to return the plain text from the cipher text.
     * @see AES
     * @param cipherText An string representing the cipher text.
     * @return String This returns the plain text.
     */
    public String returnPlainText(String cipherText) {
        System.out.println("Cipher text has been decrypted");
        return AES.decrypt(cipherText, get_secretKey(), get_salt());
    }






 
}

import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import java.util.Random;
import java.security.SecureRandom;

/**
 * The generateKey class represents the generation of keys and salts. It
 * contains methods related to generating a secret key, salt, OTP code, and hash
 * value.
 */
public class generateKey {
    /**
     * This method is used to generate a secret key.
     * @see javax.crypto.KeyGenerator
     * @see javax.crypto.SecretKey
     * @return String This returns the secret key.
     * @throws NoSuchAlgorithmException This is thrown if the algorithm is not
     *                                  found.
     */
    public static String generateSecretKey() throws NoSuchAlgorithmException {
        KeyGenerator keyGen = KeyGenerator.getInstance("AES");
        keyGen.init(128); // for example
        SecretKey secretKey = keyGen.generateKey();
        return Base64.getEncoder().encodeToString(secretKey.getEncoded());
    }

    /**
     * This method is used to generate a salt with SecureRandom class.
     * @see java.security.SecureRandom
     * @return String This returns the salt.
     */
    public static String generateSalt() {
        SecureRandom random = new SecureRandom();
        byte[] salt = new byte[16];
        random.nextBytes(salt);
        return Base64.getEncoder().encodeToString(salt);
    }

    /**
     * This method is used to generate an OTP code.
     * 
     * @return int This returns the OTP code.
     */
    public static int generateOTP() {
        Random rand = new Random();
        return rand.nextInt(9000) + 1000;
    }

    /**
     * This method is used to generate a hash value with SHA-512 algorithm.
     * @see java.security.MessageDigest
     * @param salt      A string representing the salt.
     * @param plainText A string representing the plain text.
     * @return String This returns the hash value.
     * @throws NoSuchAlgorithmException This is thrown if the algorithm is not
     *                                  found.
     */
    public static String generateHashValue(String salt, String plainText) throws NoSuchAlgorithmException {
        MessageDigest md = MessageDigest.getInstance("SHA-512");
        md.update(salt.getBytes());
        byte[] hashedValue = md.digest(plainText.getBytes());
        return Base64.getEncoder().encodeToString(hashedValue);
    }
}
